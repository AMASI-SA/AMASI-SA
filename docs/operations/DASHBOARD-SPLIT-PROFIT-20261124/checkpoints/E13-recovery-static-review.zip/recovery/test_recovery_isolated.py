"""Synthetic fixtures only; AST-selected functions, never candidate main or host guard."""
from pathlib import Path
import ast
import ctypes
import hashlib
import json
import os
import stat
import tempfile
import unittest
from unittest.mock import patch

DIRECTORY = Path(__file__).resolve().parent
CANDIDATE = DIRECTORY / 'pr2129_bytecode_preservation_recovery.py'
EXPECTED_SHA = '82d89dd2f9bae77a967f299f452e25271424a53936dc2f27570a2104115b0fc0'
SOURCE = CANDIDATE.read_bytes()
assert hashlib.sha256(SOURCE).hexdigest() == EXPECTED_SHA, 'Candidate hash changed: review before updating test binding'
TREE = ast.parse(SOURCE)
SELECTED = {
    'Blocked', 'require', 'private_json', 'fsync_directory', 'save_receipt',
    'file_fingerprint', 'live_identity', 'real_ancestors', 'sync_backup_tree',
    'pinned_bytes', 'assert_recovery_parents', 'mapped_foreign_baseline',
    'inspect_preserved_cache', 'rename_directory_noreplace', 'quarantine_exact_cache',
    'preserve_foreign', 'preserve_mapped_foreign',
}
MODULE = ast.Module(body=[node for node in TREE.body if isinstance(node, (ast.ClassDef, ast.FunctionDef))
                         and node.name in SELECTED], type_ignores=[])
assert {node.name for node in MODULE.body} == SELECTED


def environment(root):
    scope = {'__builtins__': __builtins__, 'Path': Path, 'os': os, 'stat': stat, 'json': json,
             'hashlib': hashlib, 'tempfile': tempfile, 'ctypes': ctypes}
    exec(compile(MODULE, str(CANDIDATE) + ':AST-only-synthetic', 'exec'), scope)
    scope.update(ROOT=root, STAGE=root/'receipts', RECEIPT={}, QUARANTINE=None,
                 OLD_STAGE=root/'retained-old-stage', OLD_CONTROL=root/'retained-old-control',
                 CLONE=root/'retained-old-stage/rehearsal',
                 EXPECTED_UNTRACKED=432, ALLOW_RUNTIME_APPEND=False,
                 LIVE_LOG='.live/test.log', LIVE_DB='.live/database',
                 RUNTIME_PATH='.runtime/names', RUNTIME_IDENTITY=None,
                 FOREIGN_PIN={'sha256':'synthetic-only-not-a-host-baseline'},
                 assert_live_scope=lambda: None, assert_live_write_disjoint=lambda *args: None,
                 reject_generated_mounts=lambda path: None)
    (root/'receipts').mkdir()
    (root/'.git').mkdir()
    (root/'backend').mkdir()
    cache = root/'backend/__pycache__'
    cache.mkdir(mode=0o755)
    values = {'frontend_build_identity.cpython-311.pyc': b'fixture frontend cache\x00',
              'release_protocol_v5.cpython-311.pyc': b'fixture protocol cache\x01'}
    for name,value in values.items():
        (cache/name).write_bytes(value)
        (cache/name).chmod(0o644)
    cache.chmod(0o755)
    records,identities,mtimes = {}, {}, {}
    for path in [cache,*sorted(cache.iterdir())]:
        name = path.relative_to(root).as_posix()
        info = path.lstat()
        records[name] = scope['file_fingerprint'](path)
        identities[name] = scope['live_identity'](info)
        if path != cache:
            mtimes[name] = info.st_mtime_ns
    scope.update(CACHE_REL='backend/__pycache__', CACHE_RECORDS=records,
                 CACHE_IDENTITIES=identities, CACHE_MTIMES=mtimes,
                 PARENT_IDENTITIES={name:scope['live_identity']((root/name).lstat())[:3]
                                    for name in ('.git','backend')})
    return scope


def baseline(scope):
    records = dict(scope['CACHE_RECORDS'])
    log = {'type':'file','mode':0o644,'bytes':3,'sha256':hashlib.sha256(b'log').hexdigest()}
    records[scope['LIVE_LOG']] = log
    records[scope['LIVE_DB']] = {'type':'live_directory','identity':[1,2,0o755,0,0]}
    ordinary = {'type':'directory','mode':0o755}
    for number in range(185033-len(records)):
        records[f'preserved/{number:06d}'] = ordinary
    scope['live_log_fingerprint'] = lambda prefix=None: dict(log)
    return {'git_entries':[f'untracked/{i:03d}' for i in range(432)],
            'ignored_entries':['backend/__pycache__']+[f'ignored/{i:02d}' for i in range(47)],
            'records':records}


class SyntheticRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='pr2129-recovery-fixture-')
        self.root = Path(self.temporary.name)
        self.e = environment(self.root)

    def tearDown(self):
        self.temporary.cleanup()

    def test_exact_mapping_and_other_foreign_changes(self):
        e = self.e
        before = baseline(e)
        original_keys = set(before['records'])
        mapped = e['mapped_foreign_baseline'](before)
        self.assertEqual(mapped['git_entries'], before['git_entries'])
        self.assertEqual(len(mapped['records']),185030)
        self.assertEqual(len(mapped['ignored_entries']),47)
        self.assertEqual(set(before['records']),original_keys)
        self.assertEqual(set(mapped['records'])|set(e['CACHE_RECORDS']),original_keys)
        e['quarantine_exact_cache']()
        e['untracked_snapshot'] = lambda: mapped
        e['preserve_mapped_foreign'](before)
        self.assertFalse(e['RECEIPT']['mapped_foreign_preservation']['baseline_replaced'])
        changed = {**mapped,'records':dict(mapped['records'])}
        changed['records']['preserved/000000'] = {'type':'directory','mode':0o700}
        e['untracked_snapshot'] = lambda: changed
        with self.assertRaisesRegex(e['Blocked'],'FOREIGN_ENTRY_CHANGED'):
            e['preserve_mapped_foreign'](before)
        extra = {**mapped,'git_entries':mapped['git_entries']+['unrelated-new-file']}
        e['untracked_snapshot'] = lambda: extra
        with self.assertRaisesRegex(e['Blocked'],'FOREIGN_PATH_SET_CHANGED'):
            e['preserve_mapped_foreign'](before)

    def test_mapping_rejects_broader_cache_scope(self):
        e = self.e
        before = baseline(e)
        changed = {**before,'records':dict(before['records'])}
        changed['records']['backend/nested/__pycache__'] = changed['records'].pop('preserved/000000')
        with self.assertRaisesRegex(e['Blocked'],'CACHE_BASELINE_PATH_SET_CHANGED'):
            e['mapped_foreign_baseline'](changed)
        changed = {**before,'records':dict(before['records'])}
        name = next(key for key in e['CACHE_RECORDS'] if key.endswith('.pyc'))
        changed['records'][name] = {**changed['records'][name],'sha256':'0'*64}
        with self.assertRaisesRegex(e['Blocked'],'CACHE_BASELINE_CONTENT_CHANGED'):
            e['mapped_foreign_baseline'](changed)
        changed = {**before,'ignored_entries':list(before['ignored_entries'])}
        changed['ignored_entries'][1] = 'backend/__pycache__'
        with self.assertRaisesRegex(e['Blocked'],'CACHE_IGNORED_SCOPE_CHANGED'):
            e['mapped_foreign_baseline'](changed)
        changed = {**before,'git_entries':list(before['git_entries'])}
        changed['git_entries'][0] = name
        with self.assertRaisesRegex(e['Blocked'],'CACHE_IGNORED_SCOPE_CHANGED'):
            e['mapped_foreign_baseline'](changed)

    def test_atomic_move_preserves_bytes_and_prelaunch_journal(self):
        e = self.e
        expected = e['inspect_preserved_cache'](self.root/e['CACHE_REL'])
        original = e['rename_directory_noreplace']
        observed = []
        def check_then_rename(source,destination):
            state = json.loads((e['STAGE']/'receipt.json').read_bytes())['cache_quarantine']
            self.assertEqual(state['state'],'RENAME_ARMED')
            self.assertTrue(state['move_may_have_happened'])
            self.assertFalse(state['move_confirmed'])
            observed.append(True)
            original(source,destination)
        e['rename_directory_noreplace'] = check_then_rename
        e['quarantine_exact_cache']()
        self.assertEqual(observed,[True])
        self.assertFalse(os.path.lexists(self.root/e['CACHE_REL']))
        self.assertEqual(e['inspect_preserved_cache'](e['QUARANTINE'])['records'],expected['records'])
        self.assertEqual(stat.S_IMODE(e['QUARANTINE'].parent.stat().st_mode),0o700)
        self.assertEqual(e['RECEIPT']['cache_quarantine']['state'],'PRESERVED')
        for name,metadata in expected['metadata'].items():
            actual = e['RECEIPT']['cache_quarantine']['metadata_after'][name]
            self.assertEqual(actual['identity'],metadata['identity'])
            if name != e['CACHE_REL']:
                self.assertEqual(actual['mtime_ns'],metadata['mtime_ns'])
        self.assertTrue((e['QUARANTINE'].parent/'manifest-before.json').is_file())
        self.assertTrue((e['QUARANTINE'].parent/'manifest-after.json').is_file())
        e['QUARANTINE'].parent.chmod(0o755)
        with self.assertRaisesRegex(e['Blocked'],'QUARANTINE_CONTAINER_CHANGED'):
            e['inspect_preserved_cache'](e['QUARANTINE'])
        e['QUARANTINE'].parent.chmod(0o700)

    def test_retained_ancestor_roots_and_symlink_rejection(self):
        e = self.e
        for root in (e['OLD_STAGE'],e['OLD_CONTROL']):
            root.mkdir()
            parent = root/'nested'
            parent.mkdir()
            path = parent/'receipt.json'
            path.write_bytes(b'fixture')
            e['real_ancestors'](path,root)
            alias = root/'alias'
            alias.symlink_to(parent, target_is_directory=True)
            with self.assertRaisesRegex(e['Blocked'],'SYMLINK_OR_MISSING_PARENT'):
                e['real_ancestors'](alias/'receipt.json',root)
        unknown = self.root/'unapproved-root'
        unknown.mkdir()
        with self.assertRaisesRegex(e['Blocked'],'UNEXPECTED_ANCESTOR_ROOT'):
            e['real_ancestors'](unknown/'file',unknown)
        with self.assertRaisesRegex(e['Blocked'],'PATH_ESCAPES_ROOT'):
            e['real_ancestors'](self.root/'outside-file',e['OLD_STAGE'])

    def test_destination_collision_including_after_precheck(self):
        e = self.e
        parent = self.root/'.git/test-private'
        parent.mkdir(mode=0o700)
        destination = parent/'backend-__pycache__'
        destination.mkdir()
        original_destination = destination.stat().st_ino
        source = self.root/e['CACHE_REL']
        original_source = source.stat().st_ino
        with self.assertRaisesRegex(e['Blocked'],'QUARANTINE_DESTINATION_EXISTS'):
            e['rename_directory_noreplace'](source,destination)
        actual_lexists = os.path.lexists
        def hide_only_destination(path):
            return False if Path(path) == destination else actual_lexists(path)
        with patch('os.path.lexists',side_effect=hide_only_destination):
            with self.assertRaises(FileExistsError):
                e['rename_directory_noreplace'](source,destination)
        self.assertEqual(destination.stat().st_ino,original_destination)
        self.assertEqual(source.stat().st_ino,original_source)

    def test_identity_extra_file_symlink_and_changed_bytes_refuse(self):
        e = self.e
        source = self.root/e['CACHE_REL']
        extra = source/'unexpected.pyc'
        extra.write_bytes(b'other')
        with self.assertRaisesRegex(e['Blocked'],'CACHE_CHILD_SET_CHANGED'):
            e['inspect_preserved_cache'](source)
        extra.unlink()  # Synthetic fixture only.
        name = next(key for key in e['CACHE_RECORDS'] if key.endswith('.pyc'))
        path = source/Path(name).name
        original = path.read_bytes()
        path.write_bytes(b'changed')
        os.utime(path,ns=(path.stat().st_atime_ns,e['CACHE_MTIMES'][name]))
        with self.assertRaisesRegex(e['Blocked'],'CACHE_BYTES_CHANGED'):
            e['inspect_preserved_cache'](source)
        path.write_bytes(original)
        os.utime(path,ns=(path.stat().st_atime_ns,e['CACHE_MTIMES'][name]))
        saved = self.root/'saved-cache-file'
        path.rename(saved)
        path.symlink_to(saved)
        with self.assertRaisesRegex(e['Blocked'],'CACHE_ENTRY_IDENTITY_CHANGED'):
            e['inspect_preserved_cache'](source)

    def test_failure_after_rename_is_conservative_and_no_restore(self):
        e = self.e
        original = e['rename_directory_noreplace']
        def renamed_then_failed(source,destination):
            original(source,destination)
            raise OSError('synthetic receipt/fsync boundary failure')
        e['rename_directory_noreplace'] = renamed_then_failed
        with self.assertRaises(OSError):
            e['quarantine_exact_cache']()
        state = json.loads((e['STAGE']/'receipt.json').read_bytes())['cache_quarantine']
        self.assertEqual(state['state'],'RENAME_ARMED')
        self.assertTrue(state['move_may_have_happened'])
        self.assertFalse(os.path.lexists(self.root/e['CACHE_REL']))
        self.assertEqual(e['inspect_preserved_cache'](e['QUARANTINE'])['records'],e['CACHE_RECORDS'])
        self.assertFalse(state['automatic_restore'])

    def test_cache_reappearance_and_evidence_pin_fail_closed(self):
        e = self.e
        before = baseline(e)
        e['quarantine_exact_cache']()
        (self.root/e['CACHE_REL']).mkdir()
        with self.assertRaisesRegex(e['Blocked'],'CACHE_REAPPEARED'):
            e['preserve_mapped_foreign'](before)
        evidence = self.root/'evidence.json'
        evidence.write_bytes(b'{"exact":true}\n')
        value = evidence.read_bytes()
        pin = {'bytes':len(value),'sha256':hashlib.sha256(value).hexdigest()}
        self.assertEqual(e['pinned_bytes'](evidence,pin),value)
        evidence.write_bytes(value+b'changed')
        with self.assertRaisesRegex(e['Blocked'],'PINNED_EVIDENCE_HASH_MISMATCH'):
            e['pinned_bytes'](evidence,pin)
        link = self.root/'evidence-link'
        link.symlink_to(evidence)
        with self.assertRaisesRegex(e['Blocked'],'UNSAFE_PINNED_EVIDENCE'):
            e['pinned_bytes'](link,pin)


if __name__ == '__main__':
    unittest.main(verbosity=2)
