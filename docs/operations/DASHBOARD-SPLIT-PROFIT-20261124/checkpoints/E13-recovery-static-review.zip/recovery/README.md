# PR2129 bounded bytecode-preservation recovery

**Status: FROZEN_DRAFT_PENDING_ROOT_REVIEW_PERSISTENCE_AND_FRESH_HOST_GATES.**

This package contains a new recovery operation for the exact recorded helper failure at step 78. The original attempt remains **BLOCKED, wrapper exit 2**. It successfully moved the tracked checkout from J to D and completed the owned-clone rehearsal and four output backups, but failed the strict intent validator before the canonical `/app` adapter. The fatal error was `Backend runtime source contains prepackaged bytecode: __pycache__`.

No candidate main, original guard, host operation, remote operation, lease, or publication was executed by the author of this draft. Synthetic tests use temporary local fixtures and selected function ASTs only.

## Frozen executables

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| `pr2129_bytecode_preservation_recovery.py` | 72,185 | `82d89dd2f9bae77a967f299f452e25271424a53936dc2f27570a2104115b0fc0` |
| `run-reviewed-recovery.py` | 3,915 | `e196cafb0bbbc42e59cf63025b16348b333e75260d7be77fac31bcdc51ad8400` |

The helper derives from reviewed v4 SHA256 `900cbe56a5d40e304c8975e559d4d4f77c5f4d9b0a9b77168d349d30d83a1780`. Twenty-nine original functions are byte-for-byte unchanged, including the original intent validator, adapter and post-build checks, complete foreign comparison, live Mongo/log protection, backup manifest primitives, capacity calculation, Git lineage checks, subprocess handling, and operation-lock interaction pattern. `real_ancestors` has one narrow allowlist extension for the exact retained OLD_STAGE and OLD_CONTROL roots; its other checks remain unchanged.

The historical START remains J for the unchanged lineage calculation. Every current recovery checkout assertion explicitly expects D. The new operation does not rerun the failed helper, install source, fast-forward, build another clone, restore caches, or create a lease.

## Fixed release and evidence boundary

| Binding | Value |
| --- | --- |
| J | `30c970807c05e291e2f48b35c84155b271fb5f09` |
| A | `0b39c456ea17d6e80f824f44b57563764441216c` |
| B | `ebaae98290f25db5580d888601d236431961d104` |
| D | `b651eacf5ded173c4f3224d195ef874b8bcea312` |
| B/D tree | `d50681f64d3387eb4b6f2137658be9cb11c62bd8` |
| Release ID | `rg5-37ff4cc0a52caf321810a8dce1cb6c8f1c27dd8e2f9e5f0a57944ffc90efaf5a` |
| Original stage | `/tmp/mezan-pr2122-profit-release-live-mkbhvonf` |
| Original control | `/tmp/mezan-pr2129-operator-o1l3bv1c` |
| Original receipt SHA256 | `1a134232998dc0edb7cf91e23a179d87bcebcd80330f61bf31e16cc4adaea854` |
| Original envelope SHA256 | `bbeb52d3573a8be9f1b7af30234e03121e9ac9dad1846616a5d8f5da517054a9` |
| Original foreign-before SHA256 | `caec17a1c18ccb3cd4252d4024b27652774fef66d5c13fc21ecc2255ff92c2b4` |
| Durable failure checkpoint | `0de0352250ae05a5375da56c1e498d18a6a32aa7` |

All 82 exported files in the failed-attempt manifest are pinned by exact size and SHA256, including the original helper/envelope, final wrapper state and outputs, all retained command logs, bytecode observation, and four generated-output manifests. The helper rechecks their retained host bytes. It requires the completed original wrapper journal with one invocation, exit 2, possible-running false, and both original PIDs absent. A reused PID blocks for review rather than being presumed unrelated.

The original 46,225,140-byte foreign-before inventory is intentionally not exported. Its hash and size are bound by the immutable failure packet; the new operation reads, hashes, and checks it in place before using it. Local review verified only the declared binding and the exported cache-scope subset, not the complete host inventory or actual backup contents. Fresh full comparison and backup verification remain execution gates.

The previous rooted runtime-metadata identity remains `(66329,169292,420)` for device, inode and mode. It is not adopted afresh from current state. Original live process, database-root and log identities remain unchanged from v4; database descendants are not accessed.

## Exact preservation mapping

Only these original records may change location:

| Original record | Bytes | SHA256 |
| --- | ---: | --- |
| `backend/__pycache__` | directory | identity `[66329,138446,493,0,0]` |
| `backend/__pycache__/frontend_build_identity.cpython-311.pyc` | 39,622 | `489ba93d9df88a1e4f9a7e703f5ab838f93cf60e5f6f60fe10b7eee45361b67b` |
| `backend/__pycache__/release_protocol_v5.cpython-311.pyc` | 80,941 | `c1c09df55f54c1692c24af99f4001907d6717ff06f72b95c21ec58209962143d` |

The files must retain their pinned device/inode/owner/mode, modification timestamps and complete contents. Both must be regular files with one link, with no extra children. The retained cache directory keeps its own original mode. A containing private directory is newly created under the pinned real `/app/.git`, disjoint from the release lease paths, and its identity/mode is checked again after the move.

Before relocation, the complete foreign state must satisfy the original comparison against foreign-before. After relocation, the current ordinary inventory must contain exactly the original 432 nonignored paths, 47 ignored entries instead of 48, and 185,030 records instead of 185,033. The only removed ignored entry is `backend/__pycache__`. The three removed records must separately match at the quarantine destination. No new baseline or broad cache exclusion is introduced. Original same-inode log-prefix and runtime-metadata append rules remain in force for all other paths.

The scoped observations show a complete 38-directory backend walk and no other cache or standalone `.pyc`/`.pyo` paths. An initial compile comparison used a different filename representation and reported a frontend-cache mismatch. A later read-only comparison using the recorded `co_filename` matched both complete cache files and payloads; neither observation executed cached code. These observations are retained as evidence. The recovery relies on exact preservation and the unchanged strict validator, not a bytecode-validity waiver.

## Operation sequence and crash handling

The new helper obtains an original inactive public status and then holds the unchanged original operation mutex. Under it, the operation establishes an exclusive one-attempt claim, a new private `/tmp/mezan-pr2129-bytecode-recovery-*` stage, all evidence bindings, current clean D and remote D, lineage/control checks, live-scope identities, complete original foreign equality, and current equality of all four backup copies and inherited generated outputs.

It rechecks the retained clone's original validator, frontend/package proof and runtime identity without rebuilding it. Its freshly measured generated footprint must equal the preserved successful clone receipt. Capacity is recomputed using the original formula; no space is credited to the cache relocation.

The cache move uses Linux `renameat2(RENAME_NOREPLACE)` through fixed parent directory descriptors. An unavailable primitive, destination collision, changed identity, changed file, cross-device move, or other error blocks. There is no replacement or copy/delete fallback. Both parent directories are fsynced. A durable `RENAME_ARMED` receipt with `move_may_have_happened=true` precedes the rename. Pre/post manifests and metadata are retained in the private quarantine container. Directory rename may alter timestamps such as ctime; exact file content, identity, mode, ownership and pinned file mtime remain required.

After relocation, the unchanged strict intent validator must pass. The helper rechecks mapped foreign preservation, backups, originals and capacity, then runs the unchanged canonical adapter exactly once. The adapter's original frontend verification, package verification, exact runtime identity comparison, and full frontend/proof comparison remain required. Final checks repeat the mapped preservation, backup-copy verification, remote/source/lineage checks, absence of any lease, live pins, and exact quarantine contents. Original generated outputs are intentionally compared only before the adapter replaces them; their preserved backup copies are checked again afterward.

Any failure retains the original failed stage, new stage, claim, quarantine and diagnostics. No automatic retry, restore, cleanup or rollback follows. An interruption around the rename leaves conservative possible-move evidence; the operator must inspect preserved state rather than assume nothing happened. Concurrent runtime processes can recreate caches, so source reappearance or any unexpected mutation blocks.

## One-shot capture runner

The runner is exactly seven literal replacements from the reviewed 3,865-byte `acf6fab67c1611a0666566938e407790a7be30c506c8ff8f823470c01a089aa0` runner. Reverse substitution restores its exact bytes. Its journal function is AST-identical after normalizing only the filename prefix.

After independent review and persistence, the exact files are intended for the existing private control directory: helper `pr2129_bytecode_preservation_recovery.py`, runner `run-reviewed-recovery.py`, and unchanged `execution-envelope.json`. The runner pins the helper/envelope hashes and launches the helper with only that fixed envelope, cwd `/app`, no-bytecode Python and the original environment handling. The unbounded wait preserves the original return code and stdout/stderr.

The new exclusive files are `bytecode-recovery-state.json`, `bytecode-recovery.stdout` and `bytecode-recovery.stderr`. No original `rehearsal-*` file is reused. Durable LAUNCH_ARMED precedes Popen; state updates retain the proven fresh-temp, file-fsync, replace, directory-fsync sequence. There is no runner timeout, kill, retry or phase chaining. The helper's existing bounded subprocess timeout and owned-process-group handling remain unchanged from v4.

## Focused verification

Eight isolated groups passed with exit 0 against the exact frozen helper hash. They cover the exact mapping and unrelated foreign changes; broader cache/content refusal; successful real no-replace rename with durable journal and private-parent check; retained-root allowlist, escape and symlink refusal; destination collision including a simulated race after the initial absence check; extra child, symlink and changed bytes; failure after rename with preserved uncertainty and no restore; and source reappearance plus evidence-pin refusal.

The fixtures execute only AST-selected functions in synthetic local temporary directories. They do not import or execute candidate main, original guard, old helper main, cache payloads or any production-host operation. Live-process and mount checks are isolation boundaries; their unchanged implementation is covered by the static comparison. No live execution result is claimed.

`self-review.json`, `recovery-adaptation.diff`, `runner-static-review.json`, `runner-adaptation.diff`, the focused test file and its exact output provide the review chain. `hash-manifest.json` lists only the 11 frozen package artifacts. It excludes drafting sources, stale WIP material and any separate independent/root review added later.
