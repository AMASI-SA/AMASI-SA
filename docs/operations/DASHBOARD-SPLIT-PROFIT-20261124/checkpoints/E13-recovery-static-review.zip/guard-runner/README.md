# Fixed original-guard phase runner — local draft

**Status: DRAFT_NOT_EXECUTED_PENDING_ROOT_REVIEW_AND_PERSISTENCE.**

Candidate: `run-original-guard-phase.py`, **4,722 bytes**, SHA256 `ea138c632c277bae31f40d274650505d3fb8670ee5a4b0ca01cd99bfb8fafd75`.

This is a narrow adaptation of the final independently reviewed rehearsal capture runner, SHA256 `acf6fab67c1611a0666566938e407790a7be30c506c8ff8f823470c01a089aa0`. It captures one separately selected original guard command and records its unaltered stdout, stderr and wait returncode. It has not been imported or executed. No original guard, host or remote operation occurred during preparation.

## Exact finite phase map

The runner requires exactly one phase argument and rejects every other name or extra argument before creating a state file.

| Accepted phase | Original guard arguments |
| --- | --- |
| status-before-prepare | `status` |
| prepare | `prepare --actor mezan-dashboard-profit-pr2129-20261125` |
| prepublish | `prepublish` |
| verify | `verify --url https://mezansalla.com` |
| status-after-verify | `status` |

The only subprocess site launches the current Python executable with `-B`, the fixed original guard path `/app/scripts/production_release_guard.py`, and the corresponding fixed argument vector. Child cwd is fixed to `/app`; stdin is DEVNULL and no shell is used. The runner provides no publish, abort, retry, kill, outer timeout or automatic phase-chaining capability.

Root selects each phase after its prerequisites and reviews its original output. In particular, no guard phase should run concurrently with the ongoing helper's original operation lock. Verify belongs after the separate authorized publication and explicit deployment success. The runner waits for the original guard for as long as needed; the original verifier owns its three rounds and HTTP timeouts. Running the capture runner under root's reviewed background launch preserves terminal availability without adding a timeout.

## Pinned inputs

| Input | Binding |
| --- | --- |
| Control directory | `/tmp/mezan-pr2129-operator-o1l3bv1c`, real/resolved nonsymlink directory, mode 0700 |
| Guard path | `/app/scripts/production_release_guard.py`, regular nonsymlink; /app and scripts roots real/resolved directories |
| Guard bytes | 68,995 |
| Guard SHA256 | `4e56f1f60f5f79931658b8f95a0aeb2269471025ca84f7e5b651cd284806349a` |
| Original guard Git blob | `bc03ccfae879dcfcad3fa80a7dc5e63c5aa98252`, identical in previously reviewed J/A/B/D trees |
| Envelope | `execution-envelope.json` in the control directory, regular nonsymlink mode 0600, 1,589 bytes |
| Envelope SHA256 | `bbeb52d3573a8be9f1b7af30234e03121e9ac9dad1846616a5d8f5da517054a9` |
| Envelope deployment | `b651eacf5ded173c4f3224d195ef874b8bcea312` |

Original guard bytes were read locally and their Git blob was checked against the prior independent lineage evidence. The draft does not import or monkeypatch that guard.

The pinned envelope records the expected D. Actual checkout/intent/lease validation remains in the unchanged original guard and root's phase handoff; the runner does not replace those checks or infer successful release completion from a zero-wrapper-launch result.

## Exclusive receipts and error handling

For each phase, the runner creates exactly one exclusive state/log set:

- `guard-<phase>-state.json`
- `guard-<phase>.stdout`
- `guard-<phase>.stderr`

The initial files use O_EXCL/O_NOFOLLOW and mode 0600. A prior phase state blocks reinvocation without truncating receipts.

The reviewed conservative journal is preserved: before Popen, LAUNCH_ARMED with unknown invocation count and possible-running=true is durably saved. Successful spawn records the child PID and invocation count 1. Normal completion fsyncs both original output streams, records the original wait returncode, and exits with that value. COMPLETED itself does not imply success.

Each journal update creates a fresh temporary file, fsyncs its contents, atomically replaces the state file, and fsyncs the control directory. The exception handler retains possible-running state; no child is killed and nothing is automatically retried or cleaned up. A wrapper error or interruption does not establish that a spawned original guard has stopped. Preserve the existing PID, state and outputs before any recovery decision.

PYTHONOPTIMIZE must be absent, including no string `0`, and optimized Python is rejected. Child PYTHONPATH and PYTHONOPTIMIZE are removed; PYTHONDONTWRITEBYTECODE=1 and Python `-B` disable child bytecode writes. Root should use the same unoptimized/no-bytecode convention for the wrapper itself.

## Static verification and review scope

All static checks pass: exact finite phase map and input pins; one Popen site; fixed cwd and vector; unbounded wait; no additional execution/kill capability; durable prelaunch state ordering; Python environment handling; original wait-returncode retention; and no guard import.

The complete adaptation reverses to the exact reviewed 3,865-byte rehearsal runner. The require/now functions are AST-identical. The save_state function is AST-identical after normalizing only the phase-specific temporary-name prefix. No fixture tests were run because the requested scope was local draft preparation without candidate/guard execution; root will independently review before host use.

`adaptation.diff` contains every change and `static-review.json` records the source/hash checks and limitations. This directory's hash manifest covers only this draft, its diff, its static report and this README. It makes no claim about any later separate independent-review file.
