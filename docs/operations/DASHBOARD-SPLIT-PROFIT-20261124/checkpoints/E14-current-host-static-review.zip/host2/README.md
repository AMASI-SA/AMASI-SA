# PR2129 fresh current-host boundary

**Frozen local draft; actual success requires the reviewed host execution and its final receipt.**

The original rehearsal remains BLOCKED at step 78. The later recovery was last observed RUNNING, with its strict intent check and cache-preservation comparison complete. Its final outcome is UNKNOWN because its `/tmp` receipts and backup stages are no longer available. No cause for the missing paths is asserted, and no historical final preservation claim is made.

Current rooted observation SHA256 `c379d598791e5de54edea2baa3ee83b085fbd31f2b39756dc206ba677c594801` establishes exact clean D, inactive original guard, three absent generated outputs, 4,298 empty dependency directories, new filesystem/process identities, and the surviving quarantine. Those missing outputs require a new canonical build. The durable exact-release clean-clone evidence remains valid; this operation does not repeat that build.

## Frozen inputs and operators

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `pr2129_fresh_d_rehearsal.py` | 51,504 | `cfa3dc0adf6858165a3562b3dad2a9679177112718a5d58c1a1ff9188b164ff8` |
| `run-reviewed-host2.py` | 3,915 | `dcaad9e5bcac0ab8a61f4db003dba26aa31f4d56c67e6f3b31610d59171bba84` |
| `run-original-guard-host2-phase.py` | 4,732 | `cdd43c497014e4148b5e5e95b620e3fe6162f4f540bbf16a8115bba238d46ca4` |
| `execution-envelope.json` | 1,592 | `a5bc2caf6faea02550877efa0c73320d1ee83366241a44fb399d4d222819f5a7` |

The fixed private control is `/app/.git/mezan-pr2129-host2-control-20261125`. The four files above are the complete direct execution inputs. The current observation is a hash-bound reference, with exact required values embedded in the helper; it is not another runtime input file.

The deployment remains `b651eacf5ded173c4f3224d195ef874b8bcea312`, source A remains `0b39c456ea17d6e80f824f44b57563764441216c`, and the intended release remains `rg5-37ff4cc0a52caf321810a8dce1cb6c8f1c27dd8e2f9e5f0a57944ffc90efaf5a`. The new envelope starts at D. Historical START=J is retained only for the unchanged original lineage calculation.

## Scope and persistence

Thirty-two original v4 functions are byte-identical, including the original validator, adapter, complete foreign comparison, live-scope protections, backup and storage primitives, lineage checks, and subprocess handling. The only changed retained function is `build_environment`: cache and temporary paths use separately owned WORK_STAGE instead of STAGE. This is required because the adapter rejects a toolchain cache inside `/app`.

The new flow acquires the original operation mutex after an original inactive public status. It creates one exclusive attempt claim and a unique private `/app/.git/mezan-pr2129-host2-stage-*` directory. The stage retains the helper, receipts, full fresh foreign baseline, logs, manifests, and actual current output backups. Only toolchain/cache and temporary package work use `/tmp/mezan-pr2129-host2-work-*`.

The current full foreign baseline begins with this operation. It requires 432 nonignored paths and 47 retained ignored entries; it is not compared with or presented as the lost historical baseline. Original Mongo-descendant non-access, exact process/root identities, same-inode log prefix, and bounded runtime-metadata append rules remain in force. The fixed runtime identity is the newly observed `(66345,169292,420)`.

The existing quarantine remains at `/app/.git/mezan-pr2129-bytecode-quarantine-nth6u7ce`. Its current directory/file identities, complete bytes, modes, owners and file mtimes are pinned. Its two historical manifest hashes remain unchanged. It is checked before and after the build, and is never moved, restored or rewritten. The observed device change from 66329 to 66345 is a new explicit boundary, not evidence of uninterrupted historical identity.

The first three cleanup targets must remain absent. The fourth must still be the observed 4,298 empty directories with the measured 17,649,664-byte allocation. The unchanged backup routine preserves that current tree inside the persistent stage and records absence for the other three targets. Backup/source equality is checked before their replacement; retained copies are checked again afterward.

Capacity uses current free space, inode availability, actual backup allocation and reclaimable current outputs. The 658,653,184-byte completed-output footprint is explicitly identified as the historical measurement from the exact-release successful owned clone in durable E12, with a 4,096-byte block-size gate. It is not a fresh clone measurement or a guarantee of peak build allocation. The unchanged actual adapter must still succeed.

The operator performs one unchanged canonical adapter build and all original frontend, package, exact runtime-identity and full-proof checks. Final acceptance also requires current D/remote D, full source/intent/control lineage, no lease, complete fresh-baseline preservation, existing-quarantine preservation, and valid current backup copies. There is no source installation, fast-forward, clone rebuild, old-helper replay, lease creation, publication, service restart, automatic cleanup, retry or rollback.

## Capture runners and verification

The one-shot runner is nine literal changes from reviewed baseline `acf6fab67c1611a0666566938e407790a7be30c506c8ff8f823470c01a089aa0`. The guard phase runner is three literal changes from `ea138c632c277bae31f40d274650505d3fb8670ee5a4b0ca01cd99bfb8fafd75`: control path, envelope hash and envelope length. Complete reverse substitution restores both exact reviewed originals. Each retains one Popen, an unbounded wait, durable LAUNCH_ARMED-before-spawn, fresh-temp/fsync journal updates, exclusive logs and original return codes.

The helper runner uses `host2-rehearsal-state.json`, `host2-rehearsal.stdout` and `host2-rehearsal.stderr`. The guard runner retains the five exact separate phases and the existing actor/production URL. It must be invoked phase by phase only after each prerequisite; it does not publish or chain phases.

Three focused synthetic groups passed with exit 0: external build storage and historical-capacity labeling; current absence/empty-directory validation and persistent backup behavior; and read-only quarantine preservation with refusal of changed bytes, permissions or source-cache reappearance. Only selected function ASTs ran against temporary local fixtures. Candidate main, original guard, production host and remote systems were not accessed during authoring or testing. Root and independent reviews remain separate artifacts.

The hash manifest covers the 14 listed deliverables only. Draft assembly files and separate reviewers' artifacts are excluded. Actual execution receipts must be persisted before advancing to the original prepare/prepublish/publication/three-round verification sequence.
