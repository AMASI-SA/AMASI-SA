"""Only selected functions run against synthetic local fixtures; no host main/guard."""
from pathlib import Path
import ast, hashlib, json, os, shutil, stat, tempfile, unittest

HERE=Path(__file__).resolve().parent
HELPER=HERE/'pr2129_fresh_d_rehearsal.py'
SHA='cfa3dc0adf6858165a3562b3dad2a9679177112718a5d58c1a1ff9188b164ff8'
data=HELPER.read_bytes();assert hashlib.sha256(data).hexdigest()==SHA
tree=ast.parse(data)
selected={'Blocked','require','private_json','fsync_directory','save_receipt','file_fingerprint','live_identity',
          'real_ancestors','generated_manifest','sync_backup_tree','checked_cleanup_entry','backup_generated_outputs',
          'verify_backups_and_originals','free_space','storage_measure','build_environment','inspect_current_generated',
          'verify_backup_copies','verify_existing_quarantine','check_historical_output_capacity'}
module=ast.Module(body=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in selected],type_ignores=[])
assert {n.name for n in module.body}==selected

def scope(root):
    e={'__builtins__':__builtins__,'Path':Path,'hashlib':hashlib,'json':json,'os':os,'shutil':shutil,
       'stat':stat,'tempfile':tempfile}
    exec(compile(module,str(HELPER)+':synthetic-AST-only','exec'),e)
    app=root/'app';app.mkdir();(app/'.git').mkdir();(app/'frontend').mkdir();(app/'backend').mkdir()
    stage=app/'.git/stage';stage.mkdir();work=root/'outside-work';work.mkdir()
    e.update(ROOT=app,STAGE=stage,WORK_STAGE=work,CLONE=None,RECEIPT={'backups':[]},
             CLEANUP=('frontend/build','frontend/.release','backend/release_identity.json','frontend/node_modules'),
             ENV={'GITHUB_ACTIONS':'true','GITHUB_SHA':'test','PYTHONHOME':'test','PYTHONPATH':'test',
                  'MEZAN_RELEASE_BOOTSTRAP_INTENT':'1','PYTHONDONTWRITEBYTECODE':'1'},
             reject_generated_mounts=lambda path:None)
    return e

class FreshBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='pr2129-host2-fixture-');self.root=Path(self.temp.name);self.e=scope(self.root)
    def tearDown(self):self.temp.cleanup()

    def test_external_build_storage_and_capacity_reference(self):
        e=self.e;old=dict(e['ENV']);env=e['build_environment'](e['ROOT'])
        self.assertEqual(e['ENV'],old)
        self.assertEqual(env['XDG_CACHE_HOME'],str(e['WORK_STAGE']/'cache'))
        self.assertEqual(env['TMPDIR'],str(e['WORK_STAGE']/'tmp'))
        self.assertNotIn(e['ROOT'],Path(env['XDG_CACHE_HOME']).parents)
        self.assertTrue(e['STAGE'].is_relative_to(e['ROOT']/'.git'))
        self.assertFalse(any(k.startswith('GITHUB_') for k in env))
        self.assertNotIn('PYTHONHOME',env);self.assertNotIn('MEZAN_RELEASE_BOOTSTRAP_INTENT',env)
        self.assertEqual(env['PYTHONPATH'],str(e['ROOT']/'backend')+':'+str(e['ROOT']))
        self.assertEqual(env['REACT_APP_BACKEND_URL'],'https://mezansalla.com')
        e.update(HISTORICAL_CLONE_OUTPUTS={'target_fragment_bytes':4096,'required_bytes':658653184},
                 HISTORICAL_CLONE_RECEIPT_SHA='fixture-receipt',HISTORICAL_EVIDENCE_COMMIT='fixture-commit')
        calls=[]
        def capacity(reference,*,include_source_install):
            calls.append((reference,include_source_install));e['RECEIPT'].setdefault('capacity_checks',[]).append({})
        e['check_app_capacity']=capacity
        e['free_space']=lambda path:{'fragment_bytes':4096}
        e['check_historical_output_capacity']()
        self.assertEqual(calls,[(e['HISTORICAL_CLONE_OUTPUTS'],False)])
        self.assertFalse(e['RECEIPT']['capacity_checks'][-1]['footprint_reference']['fresh_clone_measured_in_this_operation'])
        e['free_space']=lambda path:{'fragment_bytes':8192}
        with self.assertRaisesRegex(e['Blocked'],'CAPACITY_REFERENCE_BLOCK_SIZE_CHANGED'):
            e['check_historical_output_capacity']()

    def test_current_absence_empty_directories_and_persistent_backup(self):
        e=self.e;root=e['ROOT']/'frontend/node_modules';root.mkdir();(root/'one').mkdir();(root/'two').mkdir()
        measured=e['storage_measure']([root],e['ROOT'])
        e['NODE_MODULES_PIN']={'identity':e['live_identity'](root.lstat()),'entries':3,
           'required_copy_bytes':measured['required_bytes'],'allocated_bytes':measured['allocated_bytes'],
           'reclaimable_bytes':measured['reclaimable_bytes'],'reclaimable_inodes':measured['reclaimable_inodes']}
        self.assertEqual(e['inspect_current_generated'](),measured)
        e['backup_generated_outputs']();e['verify_backups_and_originals']();e['verify_backup_copies']()
        self.assertEqual([row['present'] for row in e['RECEIPT']['backups']],[False,False,False,True])
        destination=Path(e['RECEIPT']['backups'][-1]['destination'])
        self.assertTrue(destination.is_relative_to(e['ROOT']/'.git'))
        self.assertEqual(e['generated_manifest'](destination),e['generated_manifest'](root))
        (root/'new-file').write_text('unexpected')
        with self.assertRaisesRegex(e['Blocked'],'CURRENT_DEPENDENCY_CONTENT_CHANGED'):e['inspect_current_generated']()
        with self.assertRaisesRegex(e['Blocked'],'BACKUP_OR_GENERATED_OUTPUT_CHANGED'):e['verify_backups_and_originals']()
        (e['ROOT']/'frontend/build').mkdir()
        with self.assertRaisesRegex(e['Blocked'],'EXPECTED_ABSENT_OUTPUT_APPEARED'):e['inspect_current_generated']()

    def test_quarantine_current_pins_and_old_manifests_stay_read_only(self):
        e=self.e;parent=e['ROOT']/'.git/existing-quarantine';parent.mkdir(mode=0o700)
        cache=parent/'backend-__pycache__';cache.mkdir(mode=0o755)
        rows=[]
        for name,value in [('frontend_build_identity.cpython-311.pyc',b'old-front'),('release_protocol_v5.cpython-311.pyc',b'old-protocol')]:
            path=cache/name;path.write_bytes(value);path.chmod(0o644)
            rows.append({'name':name,'identity':e['live_identity'](path.lstat()),'bytes':len(value),
                         'sha256':hashlib.sha256(value).hexdigest(),'mtime_ns':path.stat().st_mtime_ns})
        pins={'path':str(parent),'parent_identity':e['live_identity'](parent.lstat()),
              'directory_identity':e['live_identity'](cache.lstat()),'files':rows}
        old_manifest_bytes=b'{"historical_device":111,"current_device_does_not_rewrite_history":true}\n'
        for name,key in [('manifest-before.json','manifest_before'),('manifest-after.json','manifest_after')]:
            path=parent/name;path.write_bytes(old_manifest_bytes);path.chmod(0o600)
            pins[key]={'bytes':len(old_manifest_bytes),'sha256':hashlib.sha256(old_manifest_bytes).hexdigest()}
        e['QUARANTINE_PIN']=pins;e['verify_existing_quarantine']()
        self.assertEqual((parent/'manifest-before.json').read_bytes(),old_manifest_bytes)
        original=rows[0];path=cache/original['name'];path.write_bytes(b'altered-cache')
        os.utime(path,ns=(path.stat().st_atime_ns,original['mtime_ns']))
        with self.assertRaisesRegex(e['Blocked'],'EXISTING_QUARANTINE_BYTES_CHANGED'):e['verify_existing_quarantine']()
        path.write_bytes(b'old-front');os.utime(path,ns=(path.stat().st_atime_ns,original['mtime_ns']))
        e['verify_existing_quarantine']();parent.chmod(0o755)
        with self.assertRaisesRegex(e['Blocked'],'EXISTING_QUARANTINE_PARENT_CHANGED'):e['verify_existing_quarantine']()
        parent.chmod(0o700);(e['ROOT']/'backend/__pycache__').mkdir()
        with self.assertRaisesRegex(e['Blocked'],'BACKEND_CACHE_REAPPEARED'):e['verify_existing_quarantine']()

if __name__=='__main__':unittest.main(verbosity=2)
