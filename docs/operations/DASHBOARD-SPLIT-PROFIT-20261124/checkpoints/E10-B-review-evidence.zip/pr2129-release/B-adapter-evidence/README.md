# B adapter evidence review

**Result: PASS_CI_ADAPTER_EVIDENCE_ONLY.** Both requested clean-clone adapter jobs completed successfully against the exact frozen B. Their sanitized evidence archives match GitHub's artifact SHA256 digests. No build was rerun, no source code was executed by this review, and no host or remote write occurred.

## Exact release binding

| Binding | Value |
| --- | --- |
| J | `30c970807c05e291e2f48b35c84155b271fb5f09` |
| A | `0b39c456ea17d6e80f824f44b57563764441216c` |
| B | `ebaae98290f25db5580d888601d236431961d104` |
| B tree | `d50681f64d3387eb4b6f2137658be9cb11c62bd8` |
| Release ID | `rg5-37ff4cc0a52caf321810a8dce1cb6c8f1c27dd8e2f9e5f0a57944ffc90efaf5a` |

[Readiness run 45653522820](https://github.com/AMASI-SA/AMASI-SA/actions/runs/45653522820), attempt 1, is completed/success. Its run metadata binds exact B and tree; checkout and job environment bind B/A/J; final adapter and package receipts bind A/release ID.

| Host Node | Successful job | Sanitized artifact | Archive SHA256 |
| --- | --- | --- | --- |
| 20.20.2 | [139344583335](https://github.com/AMASI-SA/AMASI-SA/actions/runs/45653522820/job/139344583335) | 15040154284; 63,901 bytes | `f808d748f3d2a8f482b75465471b066efd31483dd5559341d107b58b8d93b344` |
| 24.19.0 | [139344584458](https://github.com/AMASI-SA/AMASI-SA/actions/runs/45653522820/job/139344584458) | 15041094113; 63,895 bytes | `e7928afc354c96ece621435ae5eb13746459325f3657aad6a5d215a4088caaa0` |

All steps in both adapter jobs report success. Each downloaded archive contains the sanitized environment, adapter build log, package proof and governed runtime log.

## Original configured execution path

Nine relevant files have identical Git blobs at J and B: the release workflow, frontend package manifest, build dispatcher, release build script, governed runtime launcher, adapter, toolchain script, frontend verifier and release guard. The exact-B workflow blob is `3214c4b301df9622c3e9a8c8e687e5c7415b4205`; its locally reconstructed Git blob matches.

Both jobs first validate the reviewed intent/history and create a temporary tracked-source clone at exact B. They prove the generated frontend build, proof, backend identity and node_modules are absent, and prove a clean worktree. They perform a conservative frozen Host install, insert a dependency sentinel, move the clone's Git metadata out, and invoke the package command with GITHUB_ACTIONS/GITHUB_SHA/GITHUB_WORKSPACE removed.

The unchanged package command is `yarn build` → `node scripts/build-entry.cjs`. With those markers removed, the unchanged dispatcher selects the Python Emergent adapter. The adapter logs show a **cold-installed governed Node 22.23.2 / Yarn 1.22.22**, a frozen install, then `build:release` → `build-release-frontend.cjs` using Vite 8.2.4. Host Node is only the starting environment.

The unchanged workflow verifies that the Host dependency sentinel disappeared, compares generated frontend/proof/identity against the reviewed intent, checks isolated packages and backend health, restores the temporary clone's Git metadata, and verifies no worktree changes or tracked generated outputs.

The original workflow/adapter path contains no lease prepare, prepublish or publish operation; the full job logs contain no release-guard command invocation. This establishes the CI rehearsal scope. It does not establish actual-host lease state.

## Matching outputs

The complete reported frontend-build JSON, complete two-clean-build proof JSON and complete package-boundary JSON compare equal across both Host Nodes. Each proof records two matching passes with pass 2 retained.

| Output | Observed identity |
| --- | --- |
| Frontend artifact tree | `d533b15392ef10953885ba9e504c5fb0c6f854dac93b4d26e817878c49774c6d` |
| build-meta.json | 592,074 bytes; `ae007174598eb8d3fa9d59e1f3dc84c2fa17a95446918271f66a59a9c6a0c423` |
| Reproducibility proof file | 1,521 bytes; `feb69cbcb5f9ab220d1033e69bc4fd52a11b60b3280dd5a528f7baf260839127` |
| Backend identity | 504,921 bytes; `1bb5e86cc6ffcf8de2e8abc300b00760500a941666e7d3900bebbaa424921698` |
| Backend package tree | 1,361 files; `d05d8ac14add20cf4dc289e69c2b99195022b708532003bb2c49f32be4e17adf` |
| Frontend package tree | 1,834 files; `ddafce015b7f1c31de6f48554d43d169b267ed9b340fc42aea41265aa1618697` |
| Complete package proof file | `304b8eab5f7fa61532e65fec0e9577e552f835ce815ea3f2fc52922ba1958efc` |

The package proof verifies the backend in isolation with no Git directory or sibling frontend, verifies backend health, and verifies the isolated frontend runtime artifact and JSON content-type contract.

## Runtime route checks

The exact-B workflow and successful runtime step establish these assertions in CI:

- Ordinary and cache-busted `/build-meta.json` return exact JSON bytes with application/json for Accept application/json and */*, never the HTML shell.
- Requests to localhost with production and preview Host headers return those exact JSON bytes.
- A hashed asset has immutable caching and max-age=31536000.
- The `/snapchat-accounts` SPA route returns the exact HTML shell with no-store.

These are checks against the temporary CI runtime. The logs do not contain captured response bodies; evidence is the original assertion code plus successful step completion, package proofs and the started-runtime log.

## Warnings and practical limits

Each full job log contains **118 Yarn warning lines**: 92 resolution warnings, 22 peer dependency warnings and four private-workspace warnings. Selected exact strings are retained with original line numbers. These occur during the conservative Host and governed installation sequence.

Each job also emits three missing `release_identity.json` diagnostics before identity materialization. Their timing is consistent with intentionally absent generated inputs and imports before creation; the later original identity/package/health assertions and complete jobs pass.

Both runtime logs record Vite's future native-config-loader compatibility warning concerning ESM syntax in `vite.config.js` loaded as CommonJS. The governed runtime route step passes despite this warning.

The standalone environment JSON is captured **before** Git removal and says git_directory_present=true; the adapter's later environment object says false. They describe different stages. Both environment records explicitly leave platform_snapshot_workspace_shared_observed, outer_install_command_observed and outer_build_command_observed false. Declared co-parented source roots and the emulated conservative outer install do not establish real platform workspace topology or an observed actual Emergent Cloud invocation.

This review establishes exact-B CI adapter evidence only. It does not establish actual host capacity, foreign-file preservation, inactive owner lease, future D checks, deployment success or public postpublish verification. Raw generated archive file bytes are assigned to the other reviewer; this review compared the sanitized proofs and their reported identities.

## Retained evidence

`B-adapter-review.json` contains the detailed machine-readable review. `github-metadata.json` and `download-verification.json` bind the run/jobs/artifacts and their digests. `node20/` and `node24/` retain all four exact extracted artifact files. The original ZIPs are retained. Selected job excerpts retain source job IDs and original line numbers; the full fetched job logs were inspected in memory rather than persisted. `mezan-production-release-at-B.yml` and `source/` retain the exact reviewed workflow and supporting source reads. `hash-manifest.json` hashes the retained files.
