"""Audit the existing exact-A4 evidence; this does not rerun tests or call GitHub."""
from pathlib import Path
import datetime
import hashlib
import json
import re

ROOT = Path('/workspace/scratch/07c94314592d')
SUMMARY = ROOT / 'profit-backend-verification-20261125/ci-a4/a4-ci-evidence-summary.json'
raw = SUMMARY.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'cd9056d72c2caaac13f9ff161e09162b658df1bb03c5e1f9eea5b21c188a8db3'
data = json.loads(raw)
snapshot = json.loads((SUMMARY.parent / 'a4-check-runs.json').read_bytes())
checks = snapshot['check_runs']
ansi = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
jobs = []
for job in data['jobs']:
    path = Path(job['path'])
    body = path.read_bytes()
    assert len(body) == job['bytes']
    assert hashlib.sha256(body).hexdigest() == job['sha256']
    assert job['head_sha'] == data['source_sha']
    assert job['checked_out_sha'] in [data['source_sha'], data['tested_synthetic_merge']['sha']]
    text = ansi.sub('', body.decode())
    assert job['checked_out_sha'] in text
    for line in job.get('test_summary_lines', []) + job.get('build_summary_lines', []):
        assert line in text, (job['label'], line)
    matching = [check for check in checks if check['id'] == job['job']]
    assert len(matching) == 1
    assert matching[0]['head_sha'] == data['source_sha']
    assert matching[0]['conclusion'] == job['conclusion']
    jobs.append({key: job[key] for key in ['label', 'bytes', 'sha256', 'head_sha', 'checked_out_sha', 'conclusion']})
assert len(jobs) == 11
counts = {name: sum(check['conclusion'] == name for check in checks) for name in ['success', 'skipped', 'failure']}
assert counts == {'success': 29, 'skipped': 6, 'failure': 2}
assert len(checks) == 37
result = {
    'kind': 'root_independent_a4_ci_evidence_audit',
    'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_sha': data['source_sha'],
    'summary_bytes': len(raw),
    'summary_sha256': hashlib.sha256(raw).hexdigest(),
    'raw_files_and_check_bindings': 'PASS',
    'reported_summary_lines_in_ansi_normalized_raw_logs': 'PASS',
    'jobs': jobs,
    'check_counts': counts,
    'total_checks': 37,
    'all_checks_green': False,
    'limitations': data['material_limitations'],
    'count_note': data['count_note'],
    'not_a_test_rerun': True,
    'audit_note': 'An initial literal-line comparison stopped on ANSI color escapes in a Vite summary. This audit strips only ANSI CSI escapes for line comparisons, retaining exact raw-byte hash verification. No source, log, assertion under test, or test result was modified.'
}
output = ROOT / 'pr2129-release/root-ci-evidence-audit.json'
body = (json.dumps(result, indent=2) + '\n').encode()
output.write_bytes(body)
print(json.dumps({'path': str(output), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(), 'verdict': 'evidence audit PASS; A4 CodeQL remains failed', 'raw_logs': len(jobs)}))
