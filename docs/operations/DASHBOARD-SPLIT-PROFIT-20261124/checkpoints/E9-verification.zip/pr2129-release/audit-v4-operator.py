"""Independent static review of the bounded v3 -> v4 adaptation; no helper import."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import json

ROOT = Path('/workspace/scratch/07c94314592d')
BASE = ROOT / 'operator-review-current'
OLD = BASE / 'pr2122_release_operator_live_scope_v3.py'
NEW = BASE / 'v4-reviewed-host-pins/pr2122_release_operator_live_scope_v4.py'
old, new = OLD.read_bytes(), NEW.read_bytes()
assert hashlib.sha256(old).hexdigest() == 'd7832f19f5475912f3ebd0ba14c4fd2cd9b61572426f67190719c507d655a343'
assert hashlib.sha256(new).hexdigest() == '900cbe56a5d40e304c8975e559d4d4f77c5f4d9b0a9b77168d349d30d83a1780'
host_path = BASE / 'host-metadata-20261125T161909Z.json'
host_bytes = host_path.read_bytes()
assert hashlib.sha256(host_bytes).hexdigest() == '825209ecaac7f243fd5fe8b6b03d5b01dd3920d3a8ed478fb3e83b07de63a4e0'
host = json.loads(host_bytes)
old_tree, new_tree = ast.parse(old), ast.parse(new)

def assignments(tree):
    values = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        def literal(part):
            if isinstance(part, ast.Constant): return part.value
            if isinstance(part, ast.Name) and part.id in values: return values[part.id]
            if isinstance(part, (ast.List, ast.Tuple)): return [literal(v) for v in part.elts]
            if isinstance(part, ast.Dict): return {literal(k): literal(v) for k, v in zip(part.keys, part.values)}
            raise ValueError(type(part).__name__)
        try: value = literal(node.value)
        except ValueError: continue
        for target in node.targets:
            if isinstance(target, ast.Name): values[target.id] = value
    return values

before, after = assignments(old_tree), assignments(new_tree)
release = {'J': '30c970807c05e291e2f48b35c84155b271fb5f09', 'A': '0b39c456ea17d6e80f824f44b57563764441216c', 'B': 'ebaae98290f25db5580d888601d236431961d104', 'TREE': 'd50681f64d3387eb4b6f2137658be9cb11c62bd8', 'RELEASE_ID': 'rg5-37ff4cc0a52caf321810a8dce1cb6c8f1c27dd8e2f9e5f0a57944ffc90efaf5a'}
for key, value in release.items(): assert after[key] == value
expected_scope = copy.deepcopy(before['LIVE_SCOPE'])
expected_scope['process']['pid'] = host['pid']
expected_scope['process']['start_ticks'] = host['before']['start_ticks']
expected_scope['process']['exe_identity'] = host['proc_exe_identity']
for key, value in host['directories'].items(): expected_scope['directory_identities'][key] = value['identity']
expected_scope['log_identity'] = host['log']['identity']
assert after['LIVE_SCOPE'] == expected_scope
assert after['LIVE_SCOPE']['process']['cmdline_sha256'] == host['cmdline_sha256']
assert host['before']['start_ticks'] == host['after']['start_ticks']
assert host['direct_exe']['identity'] == host['proc_exe_identity']
assert host['dbpath_matches'] and not host['guard_called'] and not host['db_descendants_read']
assert all(after[name] is None for name in ['D', 'START', 'EXPECTED_UNTRACKED'])
assert after['ALLOW_RUNTIME_APPEND'] is False
old_nodes, new_nodes = list(ast.walk(old_tree)), list(ast.walk(new_tree))
assert len(old_nodes) == len(new_nodes)
offsets = [0]
for line in new.splitlines(keepends=True): offsets.append(offsets[-1] + len(line))
replacements, changes = [], []
for prior, current in zip(old_nodes, new_nodes):
    assert type(prior) is type(current)
    if isinstance(prior, ast.Constant) and prior.value != current.value:
        start = offsets[current.lineno - 1] + current.col_offset
        end = offsets[current.end_lineno - 1] + current.end_col_offset
        prior_segment = ast.get_source_segment(old.decode(), prior).encode()
        replacements.append((start, end, prior_segment))
        changes.append({'line': current.lineno, 'old': prior.value, 'new': current.value})
        current.value = prior.value
assert len(changes) == 17
assert sum(type(c['old']) is str for c in changes) == 5
assert sum(type(c['old']) is int for c in changes) == 12
assert ast.dump(old_tree, include_attributes=False) == ast.dump(new_tree, include_attributes=False)
restored = new
for start, end, body in sorted(replacements, reverse=True): restored = restored[:start] + body + restored[end:]
assert restored == old
harness = BASE / 'v4-reviewed-host-pins/ISOLATED_CHECKS.py'
verification = json.loads((harness.parent / 'verification.json').read_bytes())
log = json.loads((harness.parent / 'ISOLATED_CHECKS.log').read_bytes())
assert verification['exit_code'] == 0 and verification['stderr_bytes'] == 0
assert hashlib.sha256(harness.read_bytes()).hexdigest() == verification['harness_hash_before_and_after']
assert log == verification['checks']
assert log['groups'] == 6 and log['isolated_checks'] == 'PASS'
for key in ['main_invoked', 'adapter_invoked', 'git_or_network_invoked', 'actual_app_or_database_access', 'execution_envelope_created']: assert log[key] is False
result = {'kind': 'root_independent_v4_static_and_receipt_review', 'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'helper_sha256': hashlib.sha256(new).hexdigest(), 'host_observation_sha256': hashlib.sha256(host_bytes).hexdigest(), 'verdict': 'PASS_FOR_BOUNDED_ADAPTATION_ONLY', 'release': release, 'changes': changes, 'normalized_full_AST_equals_golden': True, 'reverse_AST_spans_restore_exact_golden_bytes': True, 'scope_equals_old_scope_with_only_observed_numeric_identity_replacements': True, 'isolated_test_receipt_groups': 6, 'isolated_tests_rerun_by_root': False, 'helper_imported_or_executed_by_root': False, 'execution_envelope_created': False, 'actual_rehearsal': False, 'remaining': ['Exact B/D gates', 'Actual merged D and lineage', 'Current predecessor closure and original inactive guard', 'Fresh execution envelope and host identity checks', 'Capacity checks and original clone/app adapter rehearsals']}
output = ROOT / 'pr2129-release/root-operator-v4-review.json'
body = (json.dumps(result, indent=2) + '\n').encode()
output.write_bytes(body)
print(json.dumps({'path': str(output), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(), 'verdict': result['verdict']}))
