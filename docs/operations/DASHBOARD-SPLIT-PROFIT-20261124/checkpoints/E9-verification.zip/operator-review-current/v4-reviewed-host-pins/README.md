# V4 operator: release bindings and reviewed host pins

**Status: NOT_EXECUTABLE_UNTIL_D_ENVELOPE_CI_AND_ROOT_REVIEW.**

This is a local review candidate for the new dashboard release. It has passed the existing six isolated fixture groups. It has not been executed against the actual host, and no D or execution envelope has been created by this review. Root's independent review, successful B/D CI, actual D, the exact reviewed envelope, completed predecessor publication/verification, and an inactive original guard remain required before actual host rehearsal.

## Exact file identities

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Golden v3 helper | 43,579 | `d7832f19f5475912f3ebd0ba14c4fd2cd9b61572426f67190719c507d655a343` |
| Release-literals-only v4 | 43,579 | `ab9702bead1502c770849a4a953f1692982b7e02310b0f7720b60fb7afb26c3f` |
| Final pinned v4 helper | 43,577 | `900cbe56a5d40e304c8975e559d4d4f77c5f4d9b0a9b77168d349d30d83a1780` |
| V4 isolated harness | 11,934 | `d43ce86c3b85e96cbb8f2d684bc14c60f963e74f8074ae64e09c5c54844815dc` |
| Root host observation | 1,955 | `825209ecaac7f243fd5fe8b6b03d5b01dd3920d3a8ed478fb3e83b07de63a4e0` |

The golden v3 helper comes from immutable evidence commit `2c6041d31c0d2dc1343885fecbe64b9e35dd4e4d`, Git blob `09f444ab079d24565381d261a628a206e2d3a705`. All candidate/support files use mode 0600. The external readiness label does not alter helper content; file permissions alone do not prevent interpretation.

## Five release bindings

| Constant | New value |
| --- | --- |
| J | `30c970807c05e291e2f48b35c84155b271fb5f09` |
| A | `0b39c456ea17d6e80f824f44b57563764441216c` |
| B | `ebaae98290f25db5580d888601d236431961d104` |
| TREE | `d50681f64d3387eb4b6f2137658be9cb11c62bd8` |
| RELEASE_ID | `rg5-37ff4cc0a52caf321810a8dce1cb6c8f1c27dd8e2f9e5f0a57944ffc90efaf5a` |

These exact bindings were supplied by root after its original and independent source/intent review. The frozen B is preserved on `codex/dashboard-split-profit-frozen-b-20261125`. This local adaptation made no additional remote calls.

## Twelve host identity literals

Root supplied the observation from 2026-11-25T16:19:09.342860+00:00. Its exact bytes/hash were checked before use. Root reported that old PID 311 was absent and a narrow process lookup identified PID 310 using the exact protected dbpath. This reviewer did not inspect the actual host.

| Identity field | Historical v3 | Fresh root observation |
| --- | ---: | ---: |
| Process PID | 311 | 310 |
| Process start ticks | 40102116 | 197045 |
| Executable device | 4194406 | 3145747 |
| Executable inode | 85818 | 86633 |
| `.worktrees` device | 66340 | 66329 |
| `.worktrees` inode | 394231 | 131957 |
| Protected parent device | 66340 | 66329 |
| Protected parent inode | 396081 | 133807 |
| DB root device | 66340 | 66329 |
| DB root inode | 396082 | 133808 |
| Sibling log device | 66340 | 66329 |
| Sibling log inode | 121637 | 400929 |

The start ticks match before and after the observation, with process state S. The full command hash remains `3afd2534eb5355d9b66e77ed088d8d3db819115b34d0e8d2901e052468cd2832`. The executable remains `/usr/bin/mongod`; its direct regular, nonsymlink identity equals the proc target identity. The three directories remain directories without symlinks at the observed entries, and the independent log remains regular without a symlink. Modes and uid/gid remain unchanged. The helper continues to require real resolved ancestors and the exact identities at execution time.

The protected DB path remains `.worktrees/p01-acceptance-state-20260919/mongo`, and the log remains its sibling `mongo.log`. Neither protected scope nor policy expands. No database descendant was read during root's observation, and no actual database/process/host was accessed by this review.

Root's metadata also records clean HEAD at J, 432 nonignored entries, 431,448,064 free bytes on /app and 271,391,502,336 on /tmp. These are point observations only. D/START/count remain unset in code; no envelope was created. Runtime metadata identity/prefix, log prefix, foreign snapshots, and all capacity requirements are still captured freshly by the unchanged helper.

The observation explicitly records `guard_called: false`. It establishes no inactive-guard result. Root states PR2128 remains under its existing publisher's ownership. This adaptation neither closes nor uses that publisher's lease.

The changed observed process and filesystem identities do not establish a cause or full host replacement. The new helper claims preservation from its own fresh baseline only; uninterrupted log-prefix continuity from the historical v3 host is not asserted.

## Complete change review

The full difference from golden v3 is **five release strings plus twelve host identity integer literals**. The twelve integers occupy six existing lines. No implementation, task label, scope path, command hash, executable path, directory set, permission mode, uid/gid, policy, original guard/adapter, environment, timeout, cleanup target, foreign preservation, backup or capacity logic changed.

A separate static verification step reconstructed the scope from the parsed AST and supplied metadata, compared every changed leaf, and normalized only the approved values. It independently used AST source spans to reverse all seventeen changed literals and reproduced golden v3 bytes exactly. The complete normalized AST also matches golden v3. D, START, EXPECTED_UNTRACKED and RUNTIME_IDENTITY remain None; ALLOW_RUNTIME_APPEND remains False.

The copied harness differs from immutable v3 only in EXPECTED, which is now the exact final helper hash. Reversing that one replacement reproduces the original harness bytes.

## Isolated verification

All six existing fixture groups passed, exit 0, in 0.2217 seconds; stderr is empty:

1. Only exact DB descendants remain unaccessed; live changes and log append pass while sibling changes/additions fail.
2. Log prefix corruption, truncation and byte-identical inode replacement fail.
3. Lexical ancestor/descendant and resolved-symlink write collisions fail.
4. Synthetic process/start, command, executable, directory and log identity mismatches fail.
5. All four generated-output backups preserve bytes, modes, literal symlinks and fsync receipts.
6. The original controlled adapter environment strips inherited GitHub/bootstrap/PYTHONHOME markers and retains owned cache/tmp and reviewed public origin.

The harness loaded the helper as a non-main module, then forbade main, protected rehearsal, subprocess runner and adapter calls. It used temporary fixtures and synthetic process metadata. Helper and harness hashes were rechecked unchanged after the run. No actual /app, database, Git/network or adapter was invoked.

These fixtures do not establish actual-host readiness, B/D CI, actual D lineage, envelope validity, inactive guard status, or successful canonical adapter execution. All original gates remain in force.

## Files

`adaptation.diff` is the complete golden-v3-to-final-v4 diff. `host-pin-only.diff` isolates the twelve pin changes atop release-only v4. `harness.diff` contains the one hash replacement. `static-verification.json` records the separate static check; `verification.json`, `ISOLATED_CHECKS.log` and `ISOLATED_CHECKS.stderr` record fixture results. `host-observation.json` is the exact root-supplied evidence. `hash-manifest.json` records all current artifact hashes.

`STATUS_V4_APPEND.md` is a local draft for later evidence persistence after root review; no repository or remote status was written.
