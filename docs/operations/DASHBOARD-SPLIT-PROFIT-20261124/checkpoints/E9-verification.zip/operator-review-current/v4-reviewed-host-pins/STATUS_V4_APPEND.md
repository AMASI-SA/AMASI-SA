## V4 operator proposal: new release bindings and fresh observed host identities

Status: **NOT_EXECUTABLE_UNTIL_D_ENVELOPE_CI_AND_ROOT_REVIEW**.

A local proposal adapts the exact E8 v3 helper to J `30c970807c05e291e2f48b35c84155b271fb5f09`, A `0b39c456ea17d6e80f824f44b57563764441216c`, B `ebaae98290f25db5580d888601d236431961d104`, common tree `d50681f64d3387eb4b6f2137658be9cb11c62bd8`, and release ID `rg5-37ff4cc0a52caf321810a8dce1cb6c8f1c27dd8e2f9e5f0a57944ffc90efaf5a`.

The proposal changes exactly five release string literals and twelve LIVE_SCOPE integer literals. Fresh root metadata from 2026-11-25T16:19:09.342860+00:00 identifies PID 310/start 197045, with the same command hash, executable path and exact protected dbpath. Executable, three directory, and sibling-log device/inode pins are updated to the supplied observations. Modes, ownership, scope paths, policies and all control flow remain unchanged.

The host observation is 1,955 bytes, SHA256 `825209ecaac7f243fd5fe8b6b03d5b01dd3920d3a8ed478fb3e83b07de63a4e0`. It reports no guard call and no DB descendant reads; this reviewer did not access the host. It does not establish inactive-guard status, full host replacement, or continuous old-log prefix preservation. Root states PR2128 remains with its original publisher.

Final helper: 43,577 bytes, SHA256 `900cbe56a5d40e304c8975e559d4d4f77c5f4d9b0a9b77168d349d30d83a1780`. Independent AST-span reversal of the seventeen literals reproduces golden v3 bytes; full normalized AST equality passes. The unchanged six fixture groups pass against this exact helper (exit 0, 0.2217 seconds, empty stderr). The harness differs only in its expected helper hash; helper/harness hashes remain unchanged after testing.

Only fixture execution occurred: no actual main/rehearsal/adapter, host, database or Git/network invocation. D/START/count remain unset, no execution envelope exists, and no lease preparation/publication/service change occurred. Successful B/D CI, actual D, root independent review, a fresh exact envelope, predecessor publication/verification closure and inactive original guard remain prerequisites. This paragraph is a local evidence draft, not a remote update.
