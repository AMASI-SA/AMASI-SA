import pathlib,subprocess,sys,json,os,datetime,time,xml.etree.ElementTree as ET,hashlib
ROOT=pathlib.Path('/workspace/scratch/07c94314592d/mezan-profit-split-current')
LOGS=pathlib.Path('/workspace/scratch/07c94314592d/profit-backend-verification-20261125')
PYTHON='/workspace/scratch/07c94314592d/profit-test-venv/bin/python'
SOURCE='0b39c456ea17d6e80f824f44b57563764441216c'
TREE='2359844effa4c2e1224794eac298d225565c5d1c'
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHON_DOTENV_DISABLED='1',PYTHONPATH=str(ROOT/'backend')+':'+str(ROOT/'backend/tests'),GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
for key in list(ENV):
    if 'MONGO' in key.upper():ENV.pop(key)
GROUPS={
 'payment-fees':[
 'test_dashboard_v2_ad_account_costs.py','test_dashboard_weekly_payment_fees.py','test_dashboard_operational_statement_fees.py',
 'test_provider_fee_statement_actual_sources.py','test_provider_fee_weekly_average.py','test_provider_fee_weekly_sources.py',
 'test_dashboard_dated_payment_fees.py','test_dashboard_split_payment_fees.py','test_dashboard_split_payment_cash_basis.py',
 'test_dashboard_card_snapshots.py','test_dashboard_weekly_read_model.py','test_dashboard_demand_builders.py',
 'test_operational_balance_configured_provider_fees.py'],
 'inherited-diagnostics':[
 'test_operational_balance_cost_order_projection.py','test_operational_balance_profit_product_stage_diagnostics.py',
 'test_operational_balance_profit_stage_diagnostics.py','test_operational_balance_cost_source_diagnostics.py'],
 'four-platform':[
 'test_dashboard_four_platform_spend_v1.py','test_dashboard_tiktok_native_spend_basis.py','test_dashboard_snapchat_spend_issue_727.py',
 'test_google_ads_reporting_v1.py','test_dashboard_ads_hourly_spend_v1.py','test_dashboard_ads_account_results.py',
 'test_dashboard_ads_costs.py','test_dashboard_dated_payment_fees.py','test_dashboard_ads_periods.py',
 'test_dashboard_runtime_source_contract.py','test_dashboard_card_snapshots.py','test_payment_method_setup.py',
 'test_payment_method_fee_status.py','test_awaiting_payment_cohort.py','test_payment_method_setup_routes.py',
 'test_dashboard_bundle_cost_authority.py','test_snapchat_reporting_v2_account_display.py','test_tiktok_scheduler_hourly.py',
 'test_ads_auto_sync_scheduler_v2.py']}
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,env=ENV,text=True).strip()
results=[]
for name in sys.argv[1:]:
    assert git('rev-parse','HEAD')==SOURCE,'source HEAD changed before tests'
    assert git('rev-parse','HEAD^{tree}')==TREE,'source tree mismatch'
    assert not git('status','--porcelain=v1','--untracked-files=all'),'checkout not clean before tests'
    junit=LOGS/('a4-'+name+'.xml')
    log=LOGS/('a4-'+name+'.log')
    argv=[PYTHON,'-B','-m','pytest','--noconftest','-p','no:cacheprovider','-q','--tb=short',
       '--basetemp='+str(LOGS/('tmp-a4-'+name)),'--junitxml='+str(junit),
       *['tests/'+p for p in GROUPS[name]]]
    record={'group':name,'source_sha':SOURCE,'source_tree':TREE,'argv':argv,'cwd':str(ROOT/'backend'),
       'environment_flags':{k:ENV[k] for k in ['PYTHONDONTWRITEBYTECODE','PYTHON_DOTENV_DISABLED','PYTHONPATH','GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH']},
       'mongodb_environment_removed':True,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'log':str(log),'junit':str(junit)}
    print(json.dumps({'started':name,'source':SOURCE,'log':str(log)}),flush=True)
    started=time.monotonic()
    with log.open('w',encoding='utf-8') as output:
        done=subprocess.run(argv,cwd=ROOT/'backend',env=ENV,stdout=output,stderr=subprocess.STDOUT)
    record.update(exit_code=done.returncode,elapsed_seconds=round(time.monotonic()-started,3),finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    if junit.exists():
        doc=ET.parse(junit);suites=doc.findall('.//testsuite')
        record['junit_totals']={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
        record['junit_sha256']=hashlib.sha256(junit.read_bytes()).hexdigest()
    record['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
    record['source_sha_after']=git('rev-parse','HEAD')
    record['status_after']=git('status','--porcelain=v1','--untracked-files=all')
    record['log_tail']=log.read_text(encoding='utf-8')[-6000:]
    (LOGS/('a4-'+name+'-result.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    results.append(record)
    print(json.dumps(record),flush=True)
    if done.returncode:break
sys.exit(max([r['exit_code'] for r in results] or [0]))
