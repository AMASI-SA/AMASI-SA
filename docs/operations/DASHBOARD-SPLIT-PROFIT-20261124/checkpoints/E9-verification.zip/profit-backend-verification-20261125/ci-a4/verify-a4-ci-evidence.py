"""Offline integrity and identity audit for the immutable A4 CI evidence packet."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import re

A4 = "0b39c456ea17d6e80f824f44b57563764441216c"
J4 = "30c970807c05e291e2f48b35c84155b271fb5f09"
TREE = "2359844effa4c2e1224794eac298d225565c5d1c"
MERGE = "00d5cc83909b5e06f6e20cd8f43dfb95ba705361"
PREFIX = "docs/operations/DASHBOARD-SPLIT-PROFIT-20261124/verification/ci-a4/"
ORIGINAL = "/workspace/scratch/07c94314592d/profit-backend-verification-20261125/ci-a4/"
MANIFEST = "a4-ci-file-manifest.json"

def require(value, message):
    if not value:
        raise SystemExit("FAIL: " + message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(directory, name):
    return json.loads((directory / name).read_bytes())

def lines(content):
    result = []
    for line in content.splitlines():
        line = line.lstrip("\ufeff")
        line = re.sub(r"^\d{4}-\d\d-\d\dT\S+Z ", "", line)
        result.append(re.sub(r"\x1b\[[0-9;]*m", "", line))
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{64}", args.manifest_sha256), "invalid expected manifest digest")
    directory = args.directory.resolve()
    manifest_path = directory / MANIFEST
    require(not manifest_path.is_symlink(), "manifest must not be a symlink")
    raw = manifest_path.read_bytes()
    require(digest(raw) == args.manifest_sha256, "manifest digest mismatch")
    manifest = json.loads(raw)
    require(manifest["source_sha"] == A4 and manifest["source_base_sha"] == J4
            and manifest["source_tree"] == TREE, "manifest source identity")
    files = manifest["files"]
    names = [entry["relative_path"] for entry in files]
    require(len(names) == len(set(names)) == 17, "expected 17 unique manifest members")
    require(MANIFEST not in names, "manifest may not claim its own digest")
    require({p.name for p in directory.iterdir()} == set(names) | {MANIFEST},
            "directory contains missing or unlisted entries")
    by_name = {}
    for entry in files:
        name = entry["relative_path"]
        require(re.fullmatch(r"[a-z0-9][a-z0-9.-]*", name) is not None, "unsafe relative path")
        require(entry["repository_path"] == PREFIX + name, "repository path binding: " + name)
        path = directory / name
        require(path.is_file() and not path.is_symlink(), "not a regular nonsymlink file: " + name)
        data = path.read_bytes()
        require(len(data) == entry["bytes"] and digest(data) == entry["sha256"],
                "file size/hash mismatch: " + name)
        by_name[name] = entry

    report = load(directory, "a4-ci-evidence-summary.json")
    audit = load(directory, "a4-ci-audit.json")
    checks = load(directory, "a4-check-runs.json")
    runs = load(directory, "a4-workflow-run-metadata.json")
    merge = load(directory, "a4-synthetic-merge.json")
    require(report["source_sha"] == audit["source_sha"] == A4, "report source")
    require(report["source_base_sha"] == audit["source_base_sha"] == J4, "report base")
    require(report["source_tree"] == audit["source_tree"] == TREE, "report tree")
    require(checks["total_count"] == len(checks["check_runs"]) == 37, "check pagination/count")
    require(all(c["head_sha"] == A4 for c in checks["check_runs"]), "check head binding")
    counts = dict(collections.Counter(c["conclusion"] if c["status"] == "completed"
                                     else c["status"] for c in checks["check_runs"]))
    counted = {"total": 37, **counts}
    require(counted == {"total": 37, "success": 29, "skipped": 6, "failure": 2},
            "recorded A4 check verdicts")
    require(report["observed_check_counts"] == audit["check_counts"] == counted, "reported check counts")
    require(report["all_A4_checks_green"] is False and audit["all_A4_checks_green"] is False,
            "CodeQL failures must remain explicit")
    require(merge["sha"] == MERGE and merge["tree"]["sha"] == TREE
            and [p["sha"] for p in merge["parents"]] == [J4, A4], "synthetic merge binding")
    require(len(runs) == 6 and all(r["head_sha"] == A4 for r in runs), "workflow source binding")
    run_by_id = {r["id"]: r for r in runs}
    for r in report["workflow_runs"]:
        original = run_by_id[r["id"]]
        for key in ("name", "path", "head_sha", "run_attempt", "event", "status", "conclusion"):
            require(r[key] == original[key], "workflow metadata mismatch")

    check_by_id = {c["id"]: c for c in checks["check_runs"]}
    require(len(report["jobs"]) == 11, "expected eleven decoded raw job logs")
    require(len([n for n in names if n.endswith(".log")]) == 11, "raw log inventory")
    for job in report["jobs"]:
        entry = by_name[job["name"]]
        require(job["path"] == ORIGINAL + job["name"], "historical path binding")
        require(entry["kind"] == "decoded_github_job_log"
                and entry["job_id"] == job["job"] and entry["run_id"] == job["run"],
                "manifest job/path binding")
        require((job["bytes"], job["sha256"]) == (entry["bytes"], entry["sha256"]),
                "report file digest binding")
        require(job["run"] in run_by_id, "unknown workflow run")
        check = check_by_id[job["job"]]
        require("/runs/" + str(job["run"]) + "/job/" + str(job["job"]) in check["details_url"],
                "job/run/check URL binding")
        require((job["status"], job["conclusion"], job["head_sha"]) ==
                (check["status"], check["conclusion"], check["head_sha"]), "job/check verdict binding")
        text = (directory / job["name"]).read_text(encoding="utf-8")
        clean = lines(text)
        marker = next(i for i, line in enumerate(clean) if "git log -1 --format=%H" in line)
        require(clean[marker + 1] == job["checked_out_sha"]
                and job["checked_out_sha"] in (A4, MERGE), "checked-out commit binding")
        summaries = [s for s in clean if re.match(r"^(Test Suites:|Tests:|\d+ passed)", s)]
        require(summaries == job["test_summary_lines"], "test counts differ from raw log")
        if "browser_pass_messages" in job:
            require([s for s in clean if s.startswith("PASS ")] == job["browser_pass_messages"],
                    "browser PASS messages differ")
        require(sum("Error: AggregateError" in s for s in clean) == job["console_aggregate_errors"],
                "console-error count differs")
        require(audit["jobs"][job["label"]]["test_summary_lines"] == summaries,
                "compact audit differs from raw log")

    patterns = {
        "private_key": r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
        "github_token": r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b",
        "openai_secret": r"\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}\b",
        "bearer_secret": r"(?i)\bBearer\s+[A-Za-z0-9._~+/-]{16,}",
        "aws_access_key": r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b",
        "unmasked_basic_auth": r"(?i)AUTHORIZATION:\s*basic\s+[A-Za-z0-9+/]{16,}={0,2}",
        "credentialed_connection_uri": r"(?i)(?:mongodb(?:\+srv)?|postgres(?:ql)?|mysql)://[^\s/:]+:[^\s@*]+@",
    }
    for name in names:
        text = (directory / name).read_text(encoding="utf-8")
        require(not any(re.search(pattern, text) for pattern in patterns.values()),
                "unmasked credential pattern requires review: " + name)
    print(json.dumps({
        "verdict": "PASS", "source_sha": A4, "source_tree": TREE,
        "manifest_sha256": digest(raw), "files_verified": len(files), "raw_logs_verified": 11,
        "check_counts": counted, "synthetic_merge_tree_equals_source": True,
        "raw_test_summary_bindings_verified": True, "credential_pattern_scan": "pass",
        "tests_rerun": False, "network_calls": False, "writes": False,
    }, sort_keys=True))

if __name__ == "__main__":
    main()
