# D host execution-envelope review

**Static review: PASS. Status: PENDING_EXACT_D_GATES_AND_PREEXECUTION_RECHECKS.**

The exact ten-key envelope is prepared for normal merge D `b651eacf5ded173c4f3224d195ef874b8bcea312`. Immutable GitHub lineage, tracked intent bindings, the unchanged helper, and root's fresh 16:47 host metadata all match. This review performed no actual-host operation and did not execute the helper.

## Frozen envelope and helper

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| execution-envelope.json | 1,589 | `bbeb52d3573a8be9f1b7af30234e03121e9ac9dad1846616a5d8f5da517054a9` |
| Reviewed v4 helper | 43,577 | `900cbe56a5d40e304c8975e559d4d4f77c5f4d9b0a9b77168d349d30d83a1780` |
| Fresh root host observation | 1,955 | `279e677bac2da5af0f20af9816c154d647e6644adcc03488e54254d2b50f75c4` |

The envelope is a regular nonsymlink file with mode 0600, below the 16,384-byte limit. It contains exactly these ten fields; readiness labels and review metadata are external:

| Field | Value |
| --- | --- |
| source_sha | `0b39c456ea17d6e80f824f44b57563764441216c` |
| source_base_sha | `30c970807c05e291e2f48b35c84155b271fb5f09` |
| intent_sha | `ebaae98290f25db5580d888601d236431961d104` |
| deployment_sha | `b651eacf5ded173c4f3224d195ef874b8bcea312` |
| tree | `d50681f64d3387eb4b6f2137658be9cb11c62bd8` |
| release_id | `rg5-37ff4cc0a52caf321810a8dce1cb6c8f1c27dd8e2f9e5f0a57944ffc90efaf5a` |
| initial_head | `30c970807c05e291e2f48b35c84155b271fb5f09` |
| expected_untracked_count | 432 |
| allow_runtime_metadata_append | true |
| live_foreign_scope | Exact JSON-equivalent LIVE_SCOPE extracted from the verified v4 helper without importing it |

The existing optional append rule remains limited to `.emergent/stripped_env_names`: a fresh regular-file identity is captured at baseline, and the existing same-device/inode/mode plus unchanged original prefix checks remain enforced. No new foreign-file exception or fixed runtime metadata identity was introduced.

The helper file and all import defaults remain unchanged. D, START and count are envelope values; no source-code constant was changed to embed D.

## Independent immutable lineage checks

GitHub GETs confirm the following:

- D has exactly the ordered parents [J, B].
- B has exactly one parent, A.
- A has exactly one parent, J.
- B and D share the exact reviewed tree `d50681f64d3387eb4b6f2137658be9cb11c62bd8`.
- The production ref equaled D when read.
- J..A contains exactly A, and its eleven source-file changes do not touch the release intent. J and A retain identical intent mode/blob, which proves the complete one-commit source history leaves that path unchanged.
- Full A/B leaf-tree comparison and the A-to-D API diff identify only `release/release-intent-v5.json`.
- All six release controls enforced by the helper retain identical modes and blobs at J, A and B/D.
- None of the four generated cleanup targets are tracked.

The tracked B/D intent blob is `d2890e7230cb60e7a181d46b7ce22af881cd6b46`, 1,532,539 bytes. It was read directly and declares schema 2/protocol 5, exact A/J/release ID, and frontend artifact `d533b15392ef10953885ba9e504c5fb0c6f854dac93b4d26e817878c49774c6d`.

The review uses complete, untruncated J/A/B trees plus the immutable commit graph and API diffs; no local checkout mutation or release-validator execution occurred.

## Fresh root observation and stage receipt

The verified observation is from **2026-11-25T16:47:12.172993+00:00**. It supersedes the 16:19 metadata for this review without changing the envelope bytes.

It reports clean HEAD at J, 432 nonignored entries, stable PID 310/start 197045, and exact matching command, executable, directory and sibling-log identity pins. The runtime metadata is regular and nonsymlink with the same identity as the earlier bounded observation. Log size is 19,828,673 bytes and runtime metadata size is 119,952 bytes. The observed free bytes are 431,251,456 on /app and 273,053,585,408 on /tmp; the unchanged helper still computes current capacity requirements itself.

The metadata receipt records no DB descendant access and no guard call. It does not establish historical log/runtime prefix continuity; no content was read. Its schema does not include branch name or resolved-root checks, which remain enforced by the unchanged operator.

Root separately reports successful predecessor original verification with three checks and lease closure, followed by original guard inactive at **16:44:46 UTC**. This reviewer did not independently call the host guard.

The local root staging receipt now exists and matches the expected 43,577-byte helper/hash at `/tmp/mezan-pr2129-operator-o1l3bv1c/pr2129_release_helper.py`, staged at 16:48:05.615826+00:00 from immutable commit `cc393bdd22db40ee49a4c9fbb010ade691d1642c`. The receipt reports helper_executed=false and app_changed=false. This reviewer read that local receipt only, not the actual host stage.

## Remaining execution gates

Require successful exact-D gates, production still at D, root's independent exact-envelope review and immutable evidence persistence. The normal immediate guard check must show inactive with no incomplete lease directory. The unchanged helper then repeats source/branch/clean/count/live-scope/root checks, holds the original operation lock, and enforces foreign snapshots, all four verified/fsynced backups, measured capacity, and both original clone/canonical adapter rehearsals.

No build/test rerun, actual-host call, remote write, source-repository write, lease preparation, publish or helper execution occurred in this review.

## Scope of this record

This review covers `execution-envelope.json`, `github-lineage-evidence.json`, `host-observation-164712Z.json`, `review.json`, and this README. The hash manifest lists only those five files.

The parent-owned `run-reviewed-rehearsal.py` wrapper is outside this review and manifest; its separate reviewer owns its assessment. This review makes no wrapper-verification claim and does not modify it.
