#!/usr/bin/env python3
"""Audit downloaded exact-B CI artifacts offline; never build or contact a host.

All writes are confined to this audit directory. The caller supplies original
GitHub artifact/job metadata, downloaded ZIPs, and decoded original job logs.
There is deliberately no default B, run ID, artifact ID, or download URL.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import zipfile


AUDIT_ROOT = Path(__file__).resolve().parent
SOURCE_A = "aec203382b387c3812509084e77c2922aa860877"
SOURCE_TREE = "f133f04fd5759c57f5cce195e35ae03ba53ef6da"
BASE_N = "44122bcc986bd1dff1532b9ad62c0268e899a179"
INTENT_SHA256 = "59da5ee6a86f3bfa5a1b8446c6aacb8e180144bc15ccaca3e414e1ec23b151ab"
RUNTIME_ID = "rg5-12e0f132b3ee688815cd2ec401bd34c43706d193492edacc7be6c5ca6e6ade8a"
HOSTS = ("20.20.2", "24.19.0")
INTENT_PATH = "release/release-intent-v5.json"
GENERATED_MEMBERS = {
    "mezan-generated-release-v5.tar.gz",
    "mezan-generated-release-v5.sha256",
}
EVIDENCE_MEMBERS = {
    "mezan-adapter-environment-v5.json",
    "mezan-adapter-build-v5.log",
    "mezan-package-boundary-v5.json",
    "mezan-governed-runtime.log",
}
REQUIRED_STEPS = (
    "Create a clean tracked-source clone",
    "Prove generated release inputs are absent",
    "Emulate a Cloud Build checkout without Git metadata",
    "Invoke the Emergent package adapter under the selected Host Node",
    "Verify artifact, proof, identity, and package boundaries",
    "Prove the governed runtime returns build metadata as JSON",
    "Archive verified generated release outputs",
    "Retain verified generated release outputs",
    "Retain sanitized rehearsal evidence",
)


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_bytes())


def write_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def metadata_payload(path: Path) -> dict:
    value = read_json(path)
    return value.get("structuredContent", value)


def exact_json(left, right) -> bool:
    return json.dumps(left, sort_keys=True, separators=(",", ":")) == json.dumps(
        right, sort_keys=True, separators=(",", ":")
    )


def safe_name(name: str) -> str:
    candidate = name[:-1] if name.endswith("/") else name
    p = PurePosixPath(candidate)
    require(
        bool(candidate) and not p.is_absolute()
        and "\\" not in candidate and "\x00" not in candidate
        and all(part not in ("", ".", "..", ".git") for part in candidate.split("/"))
        and p.as_posix() == candidate
        and all(ord(c) >= 32 and ord(c) != 127 for c in candidate),
        "Archive contains an unsafe path",
    )
    return candidate


def git(repo: Path, *args: str) -> bytes:
    result = subprocess.run(
        ["git", "-C", str(repo), *args],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
    )
    require(result.returncode == 0, "Read-only Git command failed: " + args[0])
    return result.stdout


def verify_source(repo: Path, deployment: str) -> bytes:
    require(re.fullmatch(r"[0-9a-f]{40}", deployment) is not None, "Missing full B SHA")
    require(deployment != SOURCE_A, "Source A is not intent-only B")
    require(git(repo, "rev-parse", SOURCE_A + "^{tree}").decode().strip() == SOURCE_TREE,
            "Source A tree changed")
    require(git(repo, "show", "-s", "--format=%P", SOURCE_A).decode().strip() == BASE_N,
            "Source A parent changed")
    require(git(repo, "show", "-s", "--format=%P", deployment).decode().strip() == SOURCE_A,
            "B must have exactly source A as its parent")
    require(git(repo, "diff", "--name-only", SOURCE_A, deployment).decode().splitlines() == [INTENT_PATH],
            "A-to-B changes more than the tracked intent")
    require(not git(repo, "rev-list", "--full-history", BASE_N + ".." + SOURCE_A,
                    "--", INTENT_PATH).strip(), "Source range changes old tracked intent")
    raw = git(repo, "show", deployment + ":" + INTENT_PATH)
    require(digest(raw) == INTENT_SHA256, "B intent differs from accepted candidate bytes")
    payload = json.loads(raw)
    require(payload["source_git_sha"] == SOURCE_A and payload["source_base_git_sha"] == BASE_N,
            "B intent source/base binding differs")
    require(payload["runtime_identity"]["release_id"] == RUNTIME_ID, "B runtime ID differs")
    return raw


def unpack_zip(source: Path, record: dict, target: Path) -> dict[str, bytes]:
    require(source.is_file() and not source.is_symlink(), "ZIP must be a regular local file")
    data = source.read_bytes()
    require(len(data) == record["size_in_bytes"], "ZIP size differs from GitHub metadata")
    require(record["digest"] == "sha256:" + digest(data), "ZIP digest differs from GitHub metadata")
    target.mkdir()
    (target / "artifact.zip").write_bytes(data)
    contents = {}
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        items = archive.infolist()
        require(len(items) <= 32, "Unexpected ZIP member count")
        require(sum(item.file_size for item in items) <= 512 * 1024 * 1024, "Oversized ZIP contents")
        for item in items:
            name = safe_name(item.filename)
            require(not item.is_dir() and "/" not in name, "Unexpected ZIP member shape")
            require(name not in contents and not item.flag_bits & 1, "Duplicate or encrypted ZIP member")
            kind = stat.S_IFMT(item.external_attr >> 16)
            require(kind in (0, stat.S_IFREG), "Non-regular ZIP member")
            contents[name] = archive.read(item)
            (target / name).write_bytes(contents[name])
    return contents


def extract_tar(data: bytes, target: Path, *, generated: bool, intent_bytes: bytes) -> list[dict]:
    records = []
    names = set()
    directories = []
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:*") as archive:
        members = archive.getmembers()
        require(len(members) <= 50000, "Excessive tar member count")
        require(sum(m.size for m in members) <= 2 * 1024**3, "Oversized tar contents")
        for member in members:
            name = safe_name(member.name)
            require(name not in names, "Duplicate tar member")
            names.add(name)
            require(member.isdir() or member.isreg(), "Tar links or special members are forbidden")
            mode = member.mode
            require(mode & 0o7022 == 0 and mode & 0o400, "Unsafe tar member permissions")
            if member.isdir():
                require(mode & 0o500 == 0o500, "Tar directory cannot be traversed safely")
            if generated:
                allowed = name == "frontend/build" or name.startswith("frontend/build/") or name in {
                    "frontend/.release/reproducible-build.json", "backend/release_identity.json", INTENT_PATH,
                }
                require(allowed, "Generated tar escaped its declared paths")
            destination = target / name
            for ancestor in destination.parents:
                if ancestor == target:
                    break
                require(not ancestor.is_symlink(), "Symlinked extraction ancestor")
            if member.isdir():
                destination.mkdir(parents=True, exist_ok=True, mode=0o755)
                directories.append((destination, mode))
                records.append({"path": name, "kind": "directory", "mode": f"{mode:04o}", "bytes": 0})
                continue
            handle = archive.extractfile(member)
            require(handle is not None, "Tar file body is absent")
            content = handle.read()
            require(len(content) == member.size, "Truncated tar member")
            if generated and name == INTENT_PATH:
                require(content == intent_bytes, "Generated intent is not exact B bytes")
            if destination.exists():
                require(generated and name == INTENT_PATH and destination.is_file()
                        and not destination.is_symlink() and destination.read_bytes() == content,
                        "Unexpected archive collision")
            destination.parent.mkdir(parents=True, exist_ok=True, mode=0o755)
            destination.write_bytes(content)
            destination.chmod(mode)
            records.append({"path": name, "kind": "file", "mode": f"{mode:04o}",
                            "bytes": len(content), "sha256": digest(content)})
        for directory, mode in reversed(directories):
            directory.chmod(mode)
    return sorted(records, key=lambda row: row["path"])


def run_original(repo: Path, output: Path, args: list[str], label: str) -> bytes:
    env = {"PATH": os.environ.get("PATH", os.defpath), "LANG": "C.UTF-8",
           "TMPDIR": str(output / "tmp"), "PYTHONDONTWRITEBYTECODE": "1"}
    (output / "tmp").mkdir(exist_ok=True)
    try:
        result = subprocess.run([sys.executable, "-I", "-B", *args], cwd=repo, env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    except subprocess.TimeoutExpired as error:
        (output / (label + ".stdout")).write_bytes(error.stdout or b"")
        (output / (label + ".stderr")).write_bytes(error.stderr or b"")
        raise ValueError("Original validator timed out: " + label) from error
    (output / (label + ".stdout")).write_bytes(result.stdout)
    (output / (label + ".stderr")).write_bytes(result.stderr)
    require(result.returncode == 0, "Original validator failed: " + label)
    return result.stdout


def validate_originals(repo: Path, output: Path, intent: dict, saved_boundary: dict) -> dict:
    frontend = json.loads(run_original(repo, output, ["scripts/verify_frontend_build.py",
                         "--expected-git-sha", SOURCE_A, "--reviewed-intent-v5"], "frontend-verifier"))
    require(exact_json(frontend["frontend_build"], intent["frontend_build"]), "Frontend result drift")
    require(exact_json(frontend["frontend_reproducibility"], intent["frontend_reproducibility"]), "Proof drift")
    boundary = json.loads(run_original(repo, output, ["scripts/emergent_deployment_adapter.py",
                         "verify-packages"], "package-boundary"))
    require(exact_json(boundary, saved_boundary), "Recomputed package boundaries differ from CI proof")
    health_code = (
        "import json,runpy; from pathlib import Path; "
        "a=runpy.run_path('scripts/emergent_deployment_adapter.py'); "
        "from release_identity import read_release_identity,release_health_payload; "
        "i=json.loads(Path('release/release-intent-v5.json').read_bytes()); "
        "raw=json.loads(Path('backend/release_identity.json').read_bytes()); "
        "h=read_release_identity(); hp=release_health_payload(); "
        "a['_assert_isolated_backend_health'](h,hp); "
        "ok=a['exact_json_equal'](raw,i['runtime_identity']) and "
        "all(h.get(k) is True for k in ('verified_identity_available','backend_runtime_source_verified',"
        "'release_control_source_bound','critical_file_hashes_match','frontend_build_verified')); "
        "print(json.dumps({'validated':ok,'release_id':h.get('release_id'),"
        "'source_git_sha':h.get('source_git_sha'),'source_base_git_sha':h.get('source_base_git_sha')})); "
        "raise SystemExit(0 if ok else 2)"
    )
    health = json.loads(run_original(repo, output, ["-c", health_code], "identity-health"))
    require(health == {"validated": True, "release_id": RUNTIME_ID,
                       "source_git_sha": SOURCE_A, "source_base_git_sha": BASE_N}, "Health identity drift")
    return {"frontend_identity_and_reproducibility": "PASS", "identity_health": health,
            "original_package_boundary_equals_CI": True, "package_boundary": boundary}


def review_ci_log(raw: str, job: dict, deployment: str, intent: dict) -> dict:
    log = re.sub(r"\x1b\[[0-9;]*m", "", raw)
    require(re.search(r"^\S+Z " + re.escape(deployment) + r"\s*$", log, re.M), "Job log does not show exact B checkout")
    by_name = {step["name"]: step for step in job["steps"]}
    for name in REQUIRED_STEPS:
        require(by_name.get(name, {}).get("status") == "completed"
                and by_name[name].get("conclusion") == "success", "Required CI step did not succeed: " + name)
    events = re.findall(r"^(\S+Z) Frontend build identity: ([0-9a-f]{64})\s*$", log, re.M)
    require(len(events) == 2 and all(x[1] == intent["frontend_build"]["artifact_tree_sha256"] for x in events),
            "Original job log lacks two matching actual governed builds")
    proof_sha = intent["frontend_reproducibility"]["proof_file"]["sha256"]
    require(re.search(r"^\S+Z Frontend reproducibility proof: " + proof_sha + r"\s*$", log, re.M), "Original log proof digest differs")
    route_assertions = (
        '"http://127.0.0.1:3000/build-meta.json"',
        '"http://127.0.0.1:3000/build-meta.json?release_check="',
        'for accept in ("application/json", "*/*"):',
        'assert media_type == "application/json", content_type',
        'assert body == expected',
        'assert isinstance(json.loads(body), dict)',
        'assert body != Path("build/index.html").read_bytes()',
        'assert production_body == expected',
        'assert preview_body == expected',
    )
    require(all(fragment in log for fragment in route_assertions), "Original runtime route assertions are incomplete")
    return {"two_actual_build_events": [{"at_utc": at, "artifact_tree_sha256": sha} for at, sha in events],
            "proof_sha256": proof_sha, "required_steps_succeeded": list(REQUIRED_STEPS),
            "canonical_and_cache_busted_JSON_bytes_and_MIME": "Original executed CI assertions and successful step",
            "route_target": "CI loopback 127.0.0.1:3000; not actual Emergent/Production"}


def audit(request: dict, output: Path) -> dict:
    repo = Path(request["source_repo"]).resolve(strict=True)
    deployment = request["deployment_git_sha"]
    run_id = request["run_id"]
    require(type(run_id) is int and run_id > 0, "Invalid workflow run ID")
    intent_bytes = verify_source(repo, deployment)
    intent = json.loads(intent_bytes)
    artifacts = metadata_payload(Path(request["artifacts_metadata_path"]))["artifacts"]
    jobs = metadata_payload(Path(request["jobs_metadata_path"]))["jobs"]
    artifacts_by_id = {a["id"]: a for a in artifacts}
    jobs_by_id = {j["id"]: j for j in jobs}
    require(set(request["hosts"]) == set(HOSTS), "Both actual host versions are required")
    source_tar = git(repo, "-c", "tar.umask=0022", "archive", "--format=tar", deployment,
                     "frontend", "backend", "scripts", ".github", "release")
    (output / "source-B.tar").write_bytes(source_tar)
    write_json(output / "request.json", request)
    shutil.copyfile(request["artifacts_metadata_path"], output / "github-artifacts-metadata.json")
    shutil.copyfile(request["jobs_metadata_path"], output / "github-jobs-metadata.json")
    results = {}
    all_records = {}
    used_artifacts = set()
    for host in HOSTS:
        settings = request["hosts"][host]
        host_dir = output / ("host-" + host)
        host_dir.mkdir()
        raw_log = Path(settings["job_log_path"]).read_bytes()
        (host_dir / "original-job.log").write_bytes(raw_log)
        job = jobs_by_id[settings["job_id"]]
        require(job["run_id"] == run_id and job["status"] == "completed" and job["conclusion"] == "success",
                "Host job is not a successful job of the requested run")
        require(job["name"] == "Emergent Host Node " + host + " clean-clone adapter rehearsal", "Host job name differs")
        extracted = {}
        artifact_summary = {}
        for kind in ("generated", "evidence"):
            item = settings[kind]
            record = artifacts_by_id[item["artifact_id"]]
            require(record["id"] not in used_artifacts, "An artifact was reused for multiple slots")
            used_artifacts.add(record["id"])
            expected_name = ("release-v5-generated-outputs-host-" if kind == "generated" else "release-v5-clean-clone-evidence-host-") + host
            require(record["name"] == expected_name and record.get("expired") is False, "Artifact name or expiry mismatch")
            require(record["workflow_run"]["id"] == run_id and record["workflow_run"]["head_sha"] == deployment,
                    "Artifact is not bound to exact B/run")
            extracted[kind] = unpack_zip(Path(item["zip_path"]), record, host_dir / kind)
            require(set(extracted[kind]) == (GENERATED_MEMBERS if kind == "generated" else EVIDENCE_MEMBERS),
                    "Artifact file membership differs from workflow")
            artifact_summary[kind] = {k: record[k] for k in ("id", "name", "size_in_bytes", "digest")}
        generated = extracted["generated"]
        inner = generated["mezan-generated-release-v5.tar.gz"]
        checksum = generated["mezan-generated-release-v5.sha256"].decode().strip()
        require(re.fullmatch(r"[0-9a-f]{64}  mezan-generated-release-v5\.tar\.gz", checksum) is not None
                and checksum[:64] == digest(inner), "Inner tar checksum mismatch")
        source_copy = host_dir / "source-copy"
        source_copy.mkdir(mode=0o755)
        extract_tar(source_tar, source_copy, generated=False, intent_bytes=intent_bytes)
        for absent in (".git", "frontend/build", "frontend/node_modules", "frontend/.release/reproducible-build.json", "backend/release_identity.json"):
            require(not (source_copy / absent).exists(), "Clean source copy contains generated/Git/dependency state")
        records = extract_tar(inner, source_copy, generated=True, intent_bytes=intent_bytes)
        required_files = {"frontend/build/index.html", "frontend/build/build-meta.json", "frontend/.release/reproducible-build.json",
                          "backend/release_identity.json", INTENT_PATH}
        require(required_files <= {r["path"] for r in records if r["kind"] == "file"}, "Generated required member missing")
        all_records[host] = records
        write_json(host_dir / "generated-records.json", records)
        evidence = extracted["evidence"]
        environment = json.loads(evidence["mezan-adapter-environment-v5.json"])
        require(environment["host_node"] == "v" + host and environment["host_yarn"] == "1.22.22", "Host environment evidence differs")
        require(environment["git_directory_present"] is True, "Pre-adapter evidence should observe Git checkout")
        require(all(environment[k] is False for k in (
                    "platform_snapshot_workspace_shared_observed", "outer_build_command_observed", "outer_install_command_observed")),
                "Evidence overstates actual platform observations")
        build_log = evidence["mezan-adapter-build-v5.log"].decode()
        evidence_objects = []
        decoder = json.JSONDecoder()
        for match in re.finditer(r"(?m)^\{", build_log):
            try:
                value, end = decoder.raw_decode(build_log, match.start())
                if isinstance(value, dict):
                    evidence_objects.append(value)
            except json.JSONDecodeError:
                pass
        adapter_env = next((e for e in evidence_objects if e.get("kind") == "emergent_cloud_build_evidence_v1"), None)
        require(adapter_env is not None and adapter_env["host_node"] == "v" + host
                and adapter_env["host_yarn"] == "1.22.22" and adapter_env["git_directory_present"] is False
                and adapter_env["configured_package_build_command"] == "cd frontend && yarn build",
                "Configured adapter did not observe expected host without Git")
        require(all(adapter_env[k] is False for k in (
                    "platform_snapshot_workspace_shared_observed", "outer_build_command_observed", "outer_install_command_observed")),
                "Adapter evidence overstates platform observations")
        saved_boundary = json.loads(evidence["mezan-package-boundary-v5.json"])
        built = next((e for e in evidence_objects if e.get("built") is True), None)
        require(built is not None and built["protocol_version"] == 5 and built["source_git_sha"] == SOURCE_A
                and built["release_id"] == RUNTIME_ID
                and built["frontend_artifact_tree_sha256"] == intent["frontend_build"]["artifact_tree_sha256"]
                and exact_json(built["package_boundary"], saved_boundary),
                "Adapter completion proof differs from exact source/intent/package evidence")
        original = validate_originals(source_copy, host_dir, intent, saved_boundary)
        ci = review_ci_log(raw_log.decode(), job, deployment, intent)
        results[host] = {"job_id": job["id"], "artifacts": artifact_summary,
                         "inner_tar_sha256": digest(inner), "generated_entries": len(records),
                         "generated_files": sum(r["kind"] == "file" for r in records),
                         "original_validators": original, "CI_runtime_evidence": ci}
    require(exact_json(all_records[HOSTS[0]], all_records[HOSTS[1]]), "Generated path/type/mode/size/hash differs across hosts")
    require(exact_json(results[HOSTS[0]]["original_validators"]["package_boundary"],
                       results[HOSTS[1]]["original_validators"]["package_boundary"]), "Package proofs differ across hosts")
    return {"verdict": "PASS_EXACT_B_CI_ARTIFACT_AND_ORIGINAL_VALIDATOR_AUDIT", "deployment_B": deployment,
            "source_A": SOURCE_A, "source_tree": SOURCE_TREE, "base_N": BASE_N, "runtime_release_id": RUNTIME_ID,
            "run_id": run_id, "cross_host_generated_paths_modes_sizes_hashes_equal": True,
            "cross_host_original_package_proofs_equal": True, "hosts": results,
            "limits": ["No build, install, lease or actual host publication performed by this audit.",
                       "CI loopback/runtime and isolated package verification do not prove actual Emergent platform snapshot/deployment.",
                       "No claim about unrelated workflows or all-A/all-B CI gates."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", required=True, type=Path)
    args = parser.parse_args()
    request = read_json(args.request.resolve(strict=True))
    deployment = request["deployment_git_sha"]
    require(isinstance(deployment, str) and re.fullmatch(r"[0-9a-f]{40}", deployment) is not None, "Invalid B SHA")
    run_id = request["run_id"]
    require(type(run_id) is int and run_id > 0, "Invalid run ID")
    os.umask(0o022)
    output = AUDIT_ROOT / ("run-" + str(run_id) + "-" + deployment[:12])
    output.mkdir(mode=0o755)
    try:
        result = audit(request, output)
    except Exception as error:
        result = {"verdict": "FAIL_OR_INCOMPLETE", "error_type": type(error).__name__,
                  "reason": str(error), "deployment_B": deployment, "run_id": run_id,
                  "raw_evidence_preserved": True, "output": str(output)}
        write_json(output / "report.json", result)
        print(json.dumps(result, ensure_ascii=False))
        return 1
    write_json(output / "report.json", result)
    print(json.dumps({"verdict": result["verdict"], "report": str(output / "report.json")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
