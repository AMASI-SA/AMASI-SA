from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
repo=Path('/workspace/scratch/dfe063f5aca0/mezan-server-r4')
out=Path('/workspace/scratch/dfe063f5aca0/r4-review-backend')
python=Path('/workspace/scratch/dfe063f5aca0/r4-backend-review-env/bin/python')
suites=[
'test_operational_movement_reversal_effects.py',
'test_operational_movement_reversal_routes.py',
'test_operational_workspace_account_history.py',
'test_operational_workspace_demand_reads.py',
'test_customer_inventory_unified_activity.py',
'test_operational_inventory_payment_allocation.py',
'test_inventory_payment_allocation_lineage.py',
'test_customer_refund_access.py',
'test_customer_refund_read_only_bridge.py',
'test_mobile_customer_refund_reads.py',
'test_provider_statement_employee_access.py',
'test_mobile_app_manager_role.py',
'test_mobile_app_permission_owner_resolution.py',
'test_operational_balance_app_permissions.py',
'test_operational_balance_access.py',
'test_operational_balance_web_page_grants.py',
'test_operational_workspace_refund_execution.py',
]
for name in suites:
    if not (repo/'backend/tests'/name).is_file():
        raise RuntimeError('Missing selected test: '+name)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def source_hashes():
    paths=subprocess.check_output(['git','ls-files','-z','backend'],cwd=repo).decode().split('\0')
    return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths if p and (repo/p).is_file()}
before=source_hashes()
command=[str(python),'-B','-m','pytest','--noconftest','-p','no:cacheprovider','-q',*[str(Path('backend/tests')/s) for s in suites],
'--asyncio-mode=auto','--tb=short','--junitxml='+str(out/'focused-backend.xml')]
env=dict(os.environ)
for key in ('OPERATIONAL_TEST_MONGO_URI','MZ2_TEST_MONGO_URI','DEMAND_READ_TEST_MONGO_URI','MONGO_URL','MONGO_URI','MONGODB_URI'):
    env.pop(key,None)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHON_DOTENV_DISABLED='1',PYTHONPATH='backend:backend/tests',JWT_SECRET_KEY='synthetic-r4-independent-review-only-no-live-use')
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
record={'started_at':start,'repo':str(repo),'head_before':git('rev-parse','HEAD'),'tree_before':git('rev-parse','HEAD^{tree}'),
'staged_status':git('status','--short'),'argv':command,'environment':{k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','PYTHON_DOTENV_DISABLED','PYTHONPATH')},
'python':subprocess.check_output([str(python),'--version'],text=True).strip(),'mongo':'No Mongo URI configured. Existing suites use isolated mongomock where their fixtures support it; real-Mongo proof remains CI-only.',
'source_hashes_before':before}
(out/'focused-command.json').write_text(json.dumps(record,indent=2)+'\n')
t=time.time()
with (out/'focused-backend.log').open('w') as log:
    result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
after=source_hashes()
record.update(exit_code=result.returncode,duration_seconds=round(time.time()-t,2),
finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),head_after=git('rev-parse','HEAD'),
source_hashes_after=after,source_unchanged=before==after,changed_source_paths=sorted(p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)))
(out/'focused-command.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('started_at','finished_at','exit_code','duration_seconds','head_before','head_after','source_unchanged','changed_source_paths')}))
print((out/'focused-backend.log').read_text()[-12000:])
raise SystemExit(result.returncode)
