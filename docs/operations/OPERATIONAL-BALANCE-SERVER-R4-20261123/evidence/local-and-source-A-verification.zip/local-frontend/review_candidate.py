#!/usr/bin/env python3
"""Independent original-validator audit of the downloaded exact-A CI candidate."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import runpy
import stat
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
REPO = OUT.parent / "mezan-server-r4"
EVIDENCE = OUT.parent / "r4-release-evidence"
A = "aec203382b387c3812509084e77c2922aa860877"
TREE = "f133f04fd5759c57f5cce195e35ae03ba53ef6da"
N = "44122bcc986bd1dff1532b9ad62c0268e899a179"
CANDIDATE_SHA = "59da5ee6a86f3bfa5a1b8446c6aacb8e180144bc15ccaca3e414e1ec23b151ab"
ZIP_SHA = "8963716397b59eccdd4319be1edb8fce3288adcabd57d7a025949400fe81e3f3"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(REPO), *args])


def snapshot() -> dict:
    return {"head": git("rev-parse", "HEAD").decode().strip(),
            "tree": git("rev-parse", "HEAD^{tree}").decode().strip(),
            "parents": git("show", "-s", "--format=%P", "HEAD").decode().strip().split(),
            "tracked_status": git("status", "--porcelain=v1", "--untracked-files=no").decode(),
            "inherited_intent_sha256": sha((REPO / "release/release-intent-v5.json").read_bytes())}


def main() -> None:
    before = snapshot()
    assert before["head"] == A and before["tree"] == TREE and before["parents"] == [N]
    assert before["tracked_status"] == ""
    assert (REPO / "release/release-intent-v5.json").read_bytes() == git("show", N + ":release/release-intent-v5.json")
    metadata = json.loads((OUT / "candidate-artifact-metadata.json").read_text())
    rows = [row for row in metadata["artifacts"] if row["id"] == 14815305161]
    assert len(rows) == 1
    artifact = rows[0]
    assert artifact["workflow_run"]["id"] == 45166179398
    assert artifact["workflow_run"]["head_sha"] == A
    assert artifact["workflow_run"]["head_branch"] == "codex/operational-balance-server-r4-20261123"
    assert artifact["expired"] is False
    assert artifact["digest"] == "sha256:" + ZIP_SHA and artifact["size_in_bytes"] == 432232
    zipped = (EVIDENCE / "source-A-candidate.zip").read_bytes()
    assert len(zipped) == 432232 and sha(zipped) == ZIP_SHA
    with zipfile.ZipFile(EVIDENCE / "source-A-candidate.zip") as archive:
        members = archive.infolist()
        assert len(members) == 1
        member = members[0]
        assert member.filename == "release-intent-v5.json" and member.file_size == 1502688
        assert not member.is_dir() and stat.S_IFMT(member.external_attr >> 16) in (0, stat.S_IFREG)
        extracted = archive.read(member)
    candidate = EVIDENCE / "release-intent-candidate.json"
    candidate_bytes = candidate.read_bytes()
    assert extracted == candidate_bytes and len(candidate_bytes) == 1502688 and sha(candidate_bytes) == CANDIDATE_SHA
    adapter = runpy.run_path(str(REPO / "scripts/emergent_deployment_adapter.py"), run_name="candidate_original_validator")
    intent = adapter["load_candidate_release_intent"](candidate, source_git_sha=A, source_base_git_sha=N)
    from frontend_build_identity import _tracked_frontend_source, validate_frontend_reproducibility_proof
    expected_source = intent["frontend_source"]
    actual_source = _tracked_frontend_source(repo_root=REPO, frontend_root=REPO / "frontend")
    assert actual_source == expected_source
    for key, scope in [("backend_runtime_source", adapter["BACKEND_RUNTIME_SOURCE_SCOPE"]),
                       ("release_control_source", adapter["RELEASE_CONTROL_SOURCE_SCOPE"])]:
        rebuilt = adapter["_git_source_manifest"](scope=scope, source_git_sha=A, source_base_git_sha=N)
        assert adapter["exact_json_equal"](rebuilt, intent[key]), key
    proof = validate_frontend_reproducibility_proof(frontend_build=intent["frontend_build"], proof=intent["frontend_reproducibility"])
    assert proof == intent["frontend_reproducibility"]
    after = snapshot()
    assert before == after
    validators = {}
    for path in ["scripts/emergent_deployment_adapter.py", "backend/frontend_build_identity.py", "backend/release_protocol_v5.py", "backend/release_identity.py"]:
        data = (REPO / path).read_bytes()
        assert data == git("show", A + ":" + path)
        validators[path] = sha(data)
    result = {
        "kind": "r4_independent_candidate_original_validator_review_v1",
        "result": "PASS_CANDIDATE_DIGEST_PROVENANCE_AND_ORIGINAL_VALIDATORS",
        "reviewed_utc": datetime.now(timezone.utc).isoformat(),
        "A": A, "source_tree": TREE, "N": N,
        "artifact_id": 14815305161, "run_id": 45166179398,
        "zip_bytes": len(zipped), "zip_sha256": sha(zipped),
        "candidate_bytes": len(candidate_bytes), "candidate_sha256": sha(candidate_bytes),
        "candidate_git_blob": hashlib.sha1(b"blob " + str(len(candidate_bytes)).encode() + b"\0" + candidate_bytes).hexdigest(),
        "candidate_exact_to_only_safe_ZIP_member": True,
        "original_candidate_loader": "PASS",
        "original_frontend_Git_source_rederivation": "PASS",
        "original_backend_Git_manifest_rederivation": "PASS",
        "original_release_control_Git_manifest_rederivation": "PASS",
        "original_embedded_two_build_proof_validator": "PASS",
        "source_counts": {"frontend": len(intent["frontend_source"]["files"]), "backend": len(intent["backend_runtime_source"]["files"]), "release_control": len(intent["release_control_source"]["files"])},
        "frontend_artifact_tree_sha256": intent["frontend_build"]["artifact_tree_sha256"],
        "build_meta": intent["frontend_build"]["build_meta"],
        "proof_file": proof["proof_file"],
        "runtime_release_id": intent["runtime_identity"]["release_id"],
        "original_validator_sha256": validators,
        "before": before, "after": after,
        "frozen_source_and_inherited_intent_unchanged": True,
        "limits": {
            "candidate_ZIP_contains_full_generated_build": False,
            "actual_CI_two_build_log_review": "separate candidate-provenance-review.json",
            "all_exact_A_CI_claimed": False, "B_exists_or_accepted": False,
            "actual_Emergent_host_rehearsal": False, "lease_or_publication": False,
            "duplicate_artifact_build": False,
            "expected_source_only_diagnostic": "Original release_identity import may log absent generated backend/release_identity.json; no output was materialized to satisfy it.",
        },
        "findings": [],
        "review_harness_note": "Initial audit compared the original full frontend manifest to a summary-only shape; corrected the audit to require full exact equality including files. Original source, candidate, and validators were unchanged; initial log retained.",
    }
    output = OUT / "independent-candidate-review.json"
    output.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"result": result["result"], "report_sha256": sha(output.read_bytes()), "source_counts": result["source_counts"], "runtime_release_id": result["runtime_release_id"]}, indent=2))


if __name__ == "__main__":
    main()
