#!/usr/bin/env python3
"""Run the authorized R4 affected frontend suites with the original toolchain."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / "mezan-server-r4"
BASE = "44122bcc986bd1dff1532b9ad62c0268e899a179"
SOURCE = "aec203382b387c3812509084e77c2922aa860877"
SUITES = [
    "src/pages/operational/ApprovedLedger.test.jsx",
    "src/pages/operational/ApprovedFinance.demand.test.jsx",
    "src/pages/operational/ApprovedFinance.loading.test.jsx",
    "src/pages/operational/ApprovedFinance.test.jsx",
    "src/pages/operational/ApprovedCashBoxes.test.jsx",
    "src/pages/operational/ApprovedEntry.test.jsx",
    "src/pages/operational/simpleBalancesApi.test.js",
    "src/pages/operational/simpleBalancesModel.test.js",
    "src/pages/operational/SimpleBalanceAccess.test.jsx",
    "src/pages/operational/SimpleOrderRefunds.test.jsx",
    "src/pages/operational/ProviderStatements.test.jsx",
    "src/pages/operational/providerStatementsApi.test.js",
    "src/pages/ProviderStatementAccessDialog.test.jsx",
    "src/services/providerStatementAccess.test.js",
    "src/pages/CustomerRefundAccessDialog.test.jsx",
    "src/pages/EmployeesV2Management.test.jsx",
]


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "--no-optional-locks", "-C", str(REPO), *args])


def snapshot() -> dict:
    paths = git("ls-files", "-z", "--", "frontend").decode().split("\0")
    records = []
    for relative in sorted(path for path in paths if path):
        data = (REPO / relative).read_bytes()
        records.append({"path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    encoded = json.dumps(records, sort_keys=True, separators=(",", ":")).encode()
    return {"head": git("rev-parse", "HEAD").decode().strip(), "frontend_git_tree": git("rev-parse", "HEAD:frontend").decode().strip(), "frontend_tracked_file_count": len(records),
            "frontend_file_records_sha256": hashlib.sha256(encoded).hexdigest(),
            "tracked_status": git("status", "--porcelain=v1", "--untracked-files=no", "--", "frontend").decode()}


def main() -> int:
    assert all((REPO / "frontend" / suite).is_file() for suite in SUITES)
    assert (REPO / "frontend/node_modules").is_dir(), "frozen install has not completed"
    before = snapshot()
    assert before["frontend_git_tree"] == git("rev-parse", SOURCE + ":frontend").decode().strip()
    assert not git("diff", "--name-only", SOURCE, "--", "frontend"), "frontend differs from canonical source A"
    argv = [sys.executable, "-B", str(REPO / "scripts/frontend_release_toolchain.py"), "exec", "--",
            "yarn", "--cwd", "frontend", "test", "--watchAll=false", "--runInBand", "--runTestsByPath",
            *SUITES, "--json", "--outputFile=" + str(OUT / "jest-results.json")]
    manifest = {"kind": "r4_focused_frontend_execution_v1", "base": BASE, "source_A": SOURCE,
                "started_utc": datetime.now(timezone.utc).isoformat(), "argv": argv, "cwd": str(REPO),
                "environment_overrides": {"CI": "true", "PYTHONDONTWRITEBYTECODE": "1"},
                "selected_suites": SUITES, "before": before}
    (OUT / "execution.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    env = dict(os.environ, CI="true", PYTHONDONTWRITEBYTECODE="1")
    started = time.monotonic()
    with (OUT / "frontend-tests.log").open("wb") as stream:
        result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=15 * 60)
    after = snapshot()
    unchanged = all(before[key] == after[key] for key in ("frontend_git_tree", "frontend_tracked_file_count", "frontend_file_records_sha256", "tracked_status"))
    manifest.update(exit_code=result.returncode, elapsed_seconds=round(time.monotonic() - started, 3),
                    completed_utc=datetime.now(timezone.utc).isoformat(), after=after,
                    frontend_source_unchanged=unchanged)
    if (OUT / "jest-results.json").exists():
        results = json.loads((OUT / "jest-results.json").read_text())
        names = sorted(Path(item["name"]).relative_to(REPO / "frontend").as_posix() for item in results["testResults"])
        manifest["actual_suites_match_requested"] = names == sorted(SUITES)
        manifest["jest_counts"] = {key: results.get(key) for key in ["numTotalTestSuites", "numPassedTestSuites", "numFailedTestSuites", "numPendingTestSuites", "numRuntimeErrorTestSuites", "numTotalTests", "numPassedTests", "numFailedTests", "numPendingTests", "numTodoTests", "success"]}
        manifest["suite_results"] = [{"path": str(Path(item["name"]).relative_to(REPO / "frontend")), "status": item["status"], "cases": len(item.get("assertionResults", []))} for item in results["testResults"]]
    (OUT / "execution.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
    print(json.dumps({key: manifest[key] for key in ["exit_code", "elapsed_seconds", "frontend_source_unchanged", "actual_suites_match_requested", "jest_counts"] if key in manifest}, indent=2))
    if not unchanged:
        return 2
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
