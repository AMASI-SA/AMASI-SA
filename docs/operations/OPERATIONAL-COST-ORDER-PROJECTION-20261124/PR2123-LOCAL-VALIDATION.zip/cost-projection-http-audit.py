#!/usr/bin/env python3
"""Independent, offline HTTP parity audit for one cost-source projection.

The original router, owner/page gates, saved-state readers, source runtime,
snapshot cache, report builder and disconnect handling all execute unchanged.
Only database replies are synthetic; every write capability is rejected.
Baseline source is read from immutable Git, never checked out over root's work.
"""
from __future__ import annotations

import argparse
import asyncio
from collections import Counter
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from types import ModuleType
from urllib.parse import urlencode, urlsplit

sys.dont_write_bytecode = True
BASE = "f199a471f8bc6e05b475bb9b65a12107cbdc946b"
SOURCE = "backend/operational_open_cost_exposure.py"
PREFIX = Path(__file__).with_suffix("")
FIXED_REPORT_TIME = "2026-11-24T22:00:00+00:00"
EXPECTED_TIMEOUT = "operational_source_read_timeout"


def digest(value):
    return hashlib.sha256(value).hexdigest()


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args])


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def worker(repo, variant):
    backend = repo / "backend"
    sys.path[:0] = [str(backend), str(backend / "tests")]
    source = (git(repo, "show", f"{BASE}:{SOURCE}") if variant == "baseline"
              else (repo / SOURCE).read_bytes())
    exposure = ModuleType("operational_open_cost_exposure")
    exposure.__file__ = str(repo / SOURCE)
    sys.modules[exposure.__name__] = exposure
    exec(compile(source, f"{variant}:{SOURCE}", "exec"), exposure.__dict__)

    import httpx
    from fastapi import FastAPI, HTTPException
    import operational_financial_report_read as report_reader
    import operational_read_runtime as runtime
    import operational_web_page_policy as page_policy
    from operational_balance_routes import make_operational_balance_router
    from operational_balance_store import STATES
    from test_operational_balance_supplier_workspace import ReadOnlyDB

    # Freeze only the public report's generated_at; no read budget or saved
    # snapshot time is changed. All owner/page/native dependencies stay original.
    report_reader.now = lambda: FIXED_REPORT_TIME

    class DB(ReadOnlyDB):
        def __init__(self, *, fault="timeout", changed_during_read=False):
            super().__init__()
            self.data[STATES][0]["revision"] = 7
            self.fault = fault
            self.changed_during_read = changed_during_read
            self.events, self.writes = [], []
            self.entered, self.stopped = asyncio.Event(), asyncio.Event()
            self.active = 0
            self.source_started = False
            self.owner_page_context_seen = False
            for name in exposure.READS:
                self.data.setdefault(name, [])

        def __getitem__(self, name):
            return Collection(self, name)

        def __getattr__(self, name):
            raise AssertionError(f"Unexpected database capability: {name}")

    class Collection:
        def __init__(self, db, name):
            self.db, self.name = db, name

        async def find_one(self, query, projection=None):
            self.db.events.append({"collection": self.name, "method": "find_one",
                                   "query": deepcopy(query), "projection": deepcopy(projection)})
            row = next((deepcopy(row) for row in self.db.data.get(self.name, [])
                        if all(row.get(key) == value for key, value in query.items())), None)
            # Emulate a separately changed committed snapshot in the final
            # binding read without writing even the synthetic backing data.
            if (row is not None and self.name == STATES and self.db.changed_during_read
                    and self.db.source_started and projection
                    and projection.get("revision") == 1):
                row["revision"] += 1
            return row

        def find(self, query, projection=None):
            event = {"collection": self.name, "method": "find",
                     "query": deepcopy(query), "projection": deepcopy(projection)}
            self.db.events.append(event)
            if self.name == "unified_orders":
                self.db.owner_page_context_seen = page_policy._CURRENT.get() is not None
                check(query == {"user_id": "owner"}, "Cost query changed owner/cohort")
            return Cursor(self.db, self.name, event)

        def __getattr__(self, name):
            self.db.writes.append({"collection": self.name, "method": name})
            raise AssertionError(f"Read endpoint requested unsupported/write capability {self.name}.{name}")

    class Cursor:
        def __init__(self, db, name, event):
            self.db, self.name, self.event = db, name, event

        async def to_list(self, length):
            self.event["limit"] = length
            self.db.active += 1
            try:
                if self.name == "unified_orders":
                    self.db.source_started = True
                    self.db.entered.set()
                    if self.db.fault == "block":
                        await asyncio.Event().wait()
                    raise asyncio.TimeoutError("synthetic private database timeout text")
                return []
            finally:
                self.db.active -= 1
                if self.name == "unified_orders":
                    self.db.stopped.set()

    def app_for(db, principal="owner"):
        app = FastAPI(debug=False)

        async def current_user():
            if principal is None:
                raise HTTPException(401)
            return {"id": principal}

        app.include_router(make_operational_balance_router(db, current_user), prefix="/api")
        check(not app.dependency_overrides, "Router dependencies were overridden")
        return app

    def binding(db, **changes):
        state = db.data[STATES][0]
        query = {"view": "forecast", "expected_revision": state["revision"],
                 "expected_as_of": state["engine"]["as_of"],
                 "expected_started_at": state["started_at"], "owner_id": "other"}
        query.update(changes)
        return "?" + urlencode(query)

    def summarize(db, before, response=None, *, status=None, body=None, content_type=None):
        check(db.data == before, "HTTP read modified backing data")
        check(not db.writes, f"HTTP read requested write capability: {db.writes}")
        check(db.active == 0, "Source cursor still active after HTTP completion")
        check(not exposure._READ_CACHE.entries and not exposure._READ_CACHE.inflight,
              "Failure/cancellation retained a cache entry or inflight task")
        check(not runtime.source_read_is_owned() and runtime._DEADLINE.get() is None,
              "Read ownership/deadline leaked into caller")
        check(page_policy._CURRENT.get() is None, "Page request context leaked")
        check(asyncio.all_tasks() == {asyncio.current_task()}, "HTTP read left an owned task alive")
        if response is not None:
            status, body, content_type = response.status_code, response.text, response.headers.get("content-type")
        try:
            payload = json.loads(body)
        except (ValueError, TypeError):
            payload = None
        source_queries = [e for e in db.events if e["method"] == "find"]
        orders = [e for e in source_queries if e["collection"] == "unified_orders"]
        if orders:
            check(db.owner_page_context_seen, "Source read escaped original page context")
            expected = ({"_id": 0, **dict.fromkeys(exposure.COST_ORDER_FIELDS, 1)}
                        if variant == "candidate" else None)
            check(len(orders) == 1 and orders[0]["projection"] == expected,
                  "Actual HTTP source query did not exercise expected projection")
        return {"status": status, "body": body, "content_type": content_type,
                "payload": payload, "reads": db.events,
                "source_find_count": len(source_queries), "order_find_count": len(orders),
                "source_stopped": db.stopped.is_set(),
                "original_page_context_seen": db.owner_page_context_seen,
                "writes": 0, "backing_data_unchanged": True,
                "active_source_reads": 0, "remaining_tasks": 0,
                "cache_entries": 0, "cache_inflight": 0}

    async def one(name, *, endpoint="forecast", changes=None, missing=False,
                  changed_during=False, principal="owner", disabled=False, no_page=False):
        db = DB(changed_during_read=changed_during)
        if disabled:
            db.data["users"][0]["disabled"] = True
        if no_page:
            db.data["users"][2]["web_page_access"] = {"owner_id": "owner", "revision": 1, "grants": []}
        before = deepcopy(db.data)
        path = ("/api/operational-balances/cost-exposure?owner_id=other" if endpoint == "legacy"
                else "/api/operational-balances/financial-position" +
                ("?view=forecast" if missing else binding(db, **(changes or {}))))
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app_for(db, principal),
                                    raise_app_exceptions=False), base_url="http://isolated") as client:
            response = await client.get(path)
        result = summarize(db, before, response)
        result["case"] = name
        if name == "legacy_orders_timeout":
            check(result["status"] == 500 and result["body"] == "Internal Server Error",
                  "Legacy timeout HTTP contract changed")
        elif name == "forecast_orders_timeout":
            body = result["payload"]
            check(result["status"] == 200 and body["view"] == "forecast", "Forecast should remain partial 200")
            issues = [i for i in body["issues"] if i.get("code") == EXPECTED_TIMEOUT]
            check(len(issues) == 1 and issues[0].get("source_collection") == "unified_orders",
                  "Forecast lost exact safe source failure")
            sar = body["currencies"]["SAR"]
            check(sar["metrics"]["debts_payable"] == "9135.00", "Saved balances changed on source failure")
            check(sar["metrics"]["forecast_monetary_position"] is None
                  and not sar["completeness"]["forecast"], "Forecast failure fabricated complete values")
            check("synthetic private" not in result["body"], "Private timeout text leaked")
        elif missing:
            check(result["status"] == 422 and result["payload"]["detail"]["code"] ==
                  "operational_financial_snapshot_binding_required", "Missing binding status changed")
            check(result["order_find_count"] == 0, "Missing binding read live source")
        elif changes or changed_during:
            check(result["status"] == 409 and result["payload"]["detail"]["code"] ==
                  "operational_financial_snapshot_changed", "Snapshot mismatch status changed")
            check(result["order_find_count"] == (1 if changed_during else 0), "Snapshot validation order changed")
        else:
            check(result["status"] == (401 if principal is None else 403), "Authentication/page gate changed")
            check(result["order_find_count"] == 0, "Denied actor reached cost source")
        return result

    async def disconnect():
        db = DB(fault="block")
        before = deepcopy(db.data)
        queue, sent = asyncio.Queue(), []
        queue.put_nowait({"type": "http.request", "body": b"", "more_body": False})

        async def receive():
            return await queue.get()

        async def send(message):
            sent.append(message)

        url = urlsplit("/api/operational-balances/financial-position" + binding(db))
        scope = {"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1",
                 "method": "GET", "scheme": "http", "path": url.path,
                 "raw_path": url.path.encode(), "query_string": url.query.encode(), "headers": [],
                 "client": ("127.0.0.1", 1234), "server": ("isolated", 80), "root_path": ""}
        task = asyncio.create_task(app_for(db)(scope, receive, send))
        try:
            await asyncio.wait_for(db.entered.wait(), 3)
            queue.put_nowait({"type": "http.disconnect"})
            await asyncio.wait_for(task, 3)
        finally:
            if not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        start = next(item for item in sent if item["type"] == "http.response.start")
        raw_body = b"".join(item.get("body", b"") for item in sent if item["type"] == "http.response.body")
        headers = {k.decode(): v.decode() for k,v in start["headers"]}
        result = summarize(db, before, status=start["status"], body=raw_body.decode(),
                           content_type=headers.get("content-type"))
        result["case"] = "forecast_disconnect"
        check(result["status"] == 499 and result["payload"]["detail"]["code"] ==
              "operational_report_read_cancelled", "Disconnect HTTP contract changed")
        check(result["source_stopped"] and result["order_find_count"] == 1, "Disconnect did not join source")
        return result

    async def all_cases():
        results = [await one("legacy_orders_timeout", endpoint="legacy"),
                   await one("forecast_orders_timeout"),
                   await one("forecast_missing_binding", missing=True)]
        for field, value in [("expected_revision", 8),
                             ("expected_as_of", "2026-11-02T01:00:00+03:00"),
                             ("expected_started_at", "2026-11-02T00:00:00+03:00")]:
            results.append(await one("forecast_stale_" + field, changes={field:value}))
        results.extend([await one("forecast_changed_during_read", changed_during=True),
                        await one("unauthenticated", principal=None),
                        await one("disabled_owner", disabled=True),
                        await one("staff_no_page", principal="staff", no_page=True),
                        await one("staff_owner_gate", principal="staff"),
                        await disconnect()])
        return results

    result = {"variant": variant, "base_commit": BASE, "source_sha256": digest(source),
              "result": "PASS", "case_count": 12, "cases": asyncio.run(all_cases())}
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--worker", choices=["baseline", "candidate"])
    args = parser.parse_args()
    repo = args.repo.resolve()
    if args.worker:
        worker(repo, args.worker)
        return
    tracked_readers = ["operational_balance_routes.py", "operational_financial_report_read.py",
                       "operational_financial_position_state.py", "operational_visible_report_read.py",
                       "operational_read_runtime.py", "operational_balance_sources.py",
                       "operational_web_page_policy.py", "web_page_access.py"]
    for name in tracked_readers:
        check((repo / "backend" / name).read_bytes() == git(repo, "show", f"{BASE}:backend/{name}"),
              f"Unexpected adjacent runtime change outside projection: {name}")
    before = (repo / SOURCE).read_bytes()
    started = time.monotonic()
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE":"1", "PYTHON_DOTENV_DISABLED":"1"}
    results, logs = {}, []
    for variant in ("baseline", "candidate"):
        process = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()),
                                  "--repo", str(repo), "--worker", variant],
                                 cwd=repo, env=env, text=True, capture_output=True, timeout=45)
        logs.append(f"[{variant}] exit_code={process.returncode}\n{process.stderr}")
        Path(str(PREFIX)+".log").write_text("\n".join(logs))
        if process.returncode:
            raise RuntimeError(f"{variant} failed; retained stderr in {PREFIX}.log")
        results[variant] = json.loads(process.stdout)
        Path(str(PREFIX)+f".{variant}.json").write_text(json.dumps(results[variant], ensure_ascii=False, indent=2)+"\n")
    check((repo / SOURCE).read_bytes() == before, "Candidate runtime changed during audit")
    parity=[]
    for old,new in zip(results["baseline"]["cases"],results["candidate"]["cases"]):
        check(old["case"]==new["case"], "Case ordering mismatch")
        for key in ("status","body","content_type","source_find_count","order_find_count",
                    "source_stopped","original_page_context_seen","writes","backing_data_unchanged",
                    "active_source_reads","remaining_tasks","cache_entries","cache_inflight"):
            check(old[key]==new[key], f"HTTP parity mismatch: {old['case']} {key}")
        def footprint(row):
            return [{k:v for k,v in item.items() if k!="projection"} for item in row["reads"]]
        check(footprint(old)==footprint(new), f"Read scope/count/cap changed: {old['case']}")
        for previous,current in zip(old["reads"],new["reads"]):
            if previous["collection"]!="unified_orders" or previous["method"]!="find":
                check(previous==current, f"Unrelated read projection changed: {old['case']}")
        parity.append({"case":old["case"],"status":old["status"],"full_body_and_content_type_equal":True,
                       "read_scope_and_cap_equal":True,"order_source_read_count":old["order_find_count"],
                       "writes":0,"cleanup_complete":True})
    summary={"result":"PASS","base_commit":BASE,
             "candidate_head":git(repo,"rev-parse","HEAD").decode().strip(),
             "baseline_source_sha256":results["baseline"]["source_sha256"],
             "candidate_source_sha256":digest(before),"candidate_unchanged_during_audit":True,
             "harness_sha256":digest(Path(__file__).read_bytes()),
             "seconds":round(time.monotonic()-started,3),"paired_cases":len(parity),
             "executed_http_cases":len(parity)*2,"cases":parity,
             "scope":"Actual original router, owner/page/native gates, source loader, snapshot binding/cache and ASGI disconnect lifecycle; synthetic read-only DB replies.",
             "limits":["Fault injection proves HTTP contracts and cleanup, not production timeout resolution or live latency.",
                       "Generated report timestamp was fixed identically in both processes for byte-equal response comparison.",
                       "This is an offline coroutine cursor boundary, not a real Mongo transport or performance benchmark."]}
    Path(str(PREFIX)+".json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
