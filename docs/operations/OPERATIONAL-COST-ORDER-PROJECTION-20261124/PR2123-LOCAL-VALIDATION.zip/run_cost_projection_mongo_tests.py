"""Run the seven real-Mongo cases in one owned local process lifecycle."""
from pathlib import Path
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pymongo import MongoClient
from pymongo.errors import PyMongoError

ROOT = Path('/workspace/scratch/39c6dec7c37f')
REPO = ROOT / 'operational-cost-order-projection'
EVIDENCE = ROOT / 'release-preparation'
BINARY = '/workspace/scratch/021675d08c11/location-codes-testenv/mongo/mongodb-linux-x86_64-ubuntu2204-7.0.14/bin/mongod'
stage = Path(tempfile.mkdtemp(prefix='cost-projection-supervised-mongo-', dir=EVIDENCE))
with socket.socket() as reservation:
    reservation.bind(('127.0.0.1', 0))
    port = reservation.getsockname()[1]
server = subprocess.Popen([BINARY, '--nounixsocket', '--bind_ip', '127.0.0.1', '--port', str(port),
    '--dbpath', str(stage), '--replSet', 'demandreadtest', '--wiredTigerCacheSizeGB', '0.25',
    '--logpath', str(stage / 'mongod.log')], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
direct = MongoClient(f'mongodb://127.0.0.1:{port}/?directConnection=true', serverSelectionTimeoutMS=250)
record = {'stage': str(stage), 'port': port, 'production_environment_read': False,
          'server_pid_in_this_process_namespace': server.pid, 'tests_started': False}
started = time.monotonic()
try:
    deadline = time.monotonic() + 15
    while True:
        assert server.poll() is None, 'Owned test Mongo exited'
        try:
            direct.admin.command('ping')
            break
        except PyMongoError:
            assert time.monotonic() < deadline, 'Owned test Mongo startup timed out'
            time.sleep(.05)
    direct.admin.command({'replSetInitiate': {'_id': 'demandreadtest', 'members': [
        {'_id': 0, 'host': f'127.0.0.1:{port}'}]}})
    while not direct.admin.command('hello').get('isWritablePrimary'):
        assert time.monotonic() < deadline, 'Owned test replica did not elect primary'
        time.sleep(.05)
    env = dict(os.environ, OPERATIONAL_TEST_MONGO_URI=f'mongodb://127.0.0.1:{port}/?replicaSet=demandreadtest',
               PYTHONPATH='backend:backend/tests', PYTHON_DOTENV_DISABLED='1')
    command = [sys.executable, '-B', '-m', 'pytest', '--noconftest', '-p', 'no:cacheprovider', '-q',
        'backend/tests/test_operational_balance_open_customer_cod.py::test_native_projection_is_read_only_across_repeated_runs',
        'backend/tests/test_operational_balance_cost_exposure_http.py', '--tb=short',
        '--junitxml=' + str(EVIDENCE / 'cost-projection-mongo-supervised.xml')]
    record.update(tests_started=True, command=command)
    with (EVIDENCE / 'cost-projection-mongo-supervised.log').open('w') as log:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
    record.update(exit_code=result.returncode, seconds=round(time.monotonic() - started, 3))
finally:
    direct.close()
    server.terminate()
    try:
        server.wait(timeout=10)
    except subprocess.TimeoutExpired:
        server.kill()
        server.wait(timeout=5)
    record['owned_server_stopped'] = server.poll() is not None
    (EVIDENCE / 'cost-projection-mongo-supervised.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
print((EVIDENCE / 'cost-projection-mongo-supervised.log').read_text()[-4500:])
raise SystemExit(record['exit_code'])
