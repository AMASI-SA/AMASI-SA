"""Independent local audit; never imports server or reads deployment config.

Run existing fixtures with Mongo-style top-level unified-order projection in
the shared synthetic DB and compare each cost projection with the actual
unchanged baseline module. The baseline and candidate see independent copies
of synthetic inputs. A populated local-Mongo fixture may be read twice only
after verifying its client address is loopback.
"""
from __future__ import annotations

import contextvars
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import types

import pytest

ROOT = Path('/workspace/scratch/39c6dec7c37f/operational-cost-order-projection')
OUT = Path('/workspace/scratch/39c6dec7c37f/release-preparation')
BASE = 'f199a471f8bc6e05b475bb9b65a12107cbdc946b'
RUNTIME = 'backend/operational_open_cost_exposure.py'
PHASE = contextvars.ContextVar('independent_cost_projection_phase', default='fixture')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), default=str).encode('utf-8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def signature(error):
    return (type(error).__module__, type(error).__qualname__, error.args,
            str(error), getattr(error, 'code', None), getattr(error, 'collection', None))


class Audit:
    def __init__(self):
        self.current_test = None
        self.comparisons = []
        self.queries = []
        self.motor_queries = []
        self.tests = []
        self.omitted = []
        self.incomparable = []

    def pytest_addoption(self, parser):
        parser.addoption('--independent-output-label', default='result')
        parser.addoption('--independent-owned-mongo', action='store_true', default=False)

    @pytest.fixture(scope='session', autouse=True)
    def independent_test_server(self, tmp_path_factory, request):
        if not request.config.getoption('--independent-owned-mongo'):
            yield
            return
        assert not os.environ.get('DEMAND_READ_TEST_MONGO_URI')
        assert not os.environ.get('OPERATIONAL_TEST_MONGO_URI')
        from demand_read_mongo_fixture import read_mongo_uri
        owned = read_mongo_uri.__wrapped__(tmp_path_factory, request)
        uri = next(owned)
        os.environ['OPERATIONAL_TEST_MONGO_URI'] = uri
        try:
            yield
        finally:
            os.environ.pop('OPERATIONAL_TEST_MONGO_URI', None)
            try:
                next(owned)
            except StopIteration:
                pass

    def pytest_configure(self, config):
        import operational_open_cost_exposure as candidate
        import test_operational_balance_sources as fixtures
        from operational_financial_position_core import build_financial_position

        self.output_label = config.getoption('--independent-output-label')
        assert self.output_label and all(ch.isalnum() or ch == '-' for ch in self.output_label)

        baseline_source = subprocess.check_output(
            ['git', 'show', BASE + ':' + RUNTIME], cwd=ROOT)
        baseline = types.ModuleType('cost_projection_independent_baseline')
        baseline.__file__ = '<baseline:' + BASE + ':' + RUNTIME + '>'
        sys.modules[baseline.__name__] = baseline
        exec(compile(baseline_source, baseline.__file__, 'exec'), baseline.__dict__)
        self.baseline_sha256 = hashlib.sha256(baseline_source).hexdigest()
        self.candidate_sha256 = hashlib.sha256((ROOT / RUNTIME).read_bytes()).hexdigest()
        self.fields = list(candidate.COST_ORDER_FIELDS)
        self.candidate, self.baseline = candidate, baseline
        self.old_find = fixtures.Collection.find
        self.old_project = candidate._project
        audit = self

        def honoring_find(collection, query, projection=None):
            cursor = audit.old_find(collection, query, projection)
            if collection.name == 'unified_orders':
                assert query == {'user_id': 'owner'}
                before = deepcopy(cursor.values)
                if projection:
                    assert projection.get('_id') == 0
                    assert all('.' not in key for key in projection)
                    assert all(value in (0, 1) for value in projection.values())
                    cursor.values = [{key: value for key, value in row.items()
                                      if projection.get(key) == 1}
                                     for row in cursor.values]
                audit.queries.append({
                    'test': audit.current_test, 'phase': PHASE.get(),
                    'projection_fields': sorted(key for key, value in (projection or {}).items() if value == 1),
                    'rows': len(cursor.values), 'row_count_preserved': len(cursor.values) == len(before),
                    'all_rows_exact_owner': all(row.get('user_id') == 'owner' for row in cursor.values),
                    'whole_raw_preserved': all(
                        ('raw_by_source' in a) == ('raw_by_source' in b)
                        and a.get('raw_by_source') == b.get('raw_by_source')
                        for a, b in zip(before, cursor.values)),
                })
            return cursor

        fixtures.Collection.find = honoring_find

        from motor.motor_asyncio import AsyncIOMotorCollection
        self.old_motor_find = AsyncIOMotorCollection.find

        def observe_motor_find(collection, *args, **kwargs):
            if collection.name == 'unified_orders' and PHASE.get() in {'baseline', 'candidate'}:
                query = args[0] if args else kwargs.get('filter', {})
                projection = args[1] if len(args) > 1 else kwargs.get('projection')
                audit.motor_queries.append({'test': audit.current_test, 'phase': PHASE.get(),
                    'query': deepcopy(query), 'projection': deepcopy(projection)})
            return audit.old_motor_find(collection, *args, **kwargs)

        AsyncIOMotorCollection.find = observe_motor_find

        async def compared_project(database, owner, state, *, as_of=None):
            if isinstance(database, fixtures.DB):
                baseline_db = object.__new__(type(database))
                for name, value in vars(database).items():
                    setattr(baseline_db, name, deepcopy(value))
                before_data = deepcopy(database.data)
                fixture_kind = type(database).__name__
            else:
                from motor.motor_asyncio import AsyncIOMotorDatabase
                if not isinstance(database, AsyncIOMotorDatabase):
                    audit.incomparable.append({'test': audit.current_test,
                                               'database_class': type(database).__name__})
                    return await audit.old_project(database, owner, state, as_of=as_of)
                address = database.client.address
                assert address is not None and address[0] == '127.0.0.1', 'Local test Mongo only'
                assert database.name.startswith(('operational_', 'bundle_', 'test_', 'read_'))
                baseline_db, before_data = database, None
                fixture_kind = 'actual_loopback_mongo'
            before_state = deepcopy(state)
            outcomes, failures = [], []
            for phase, function, db_arg, state_arg in (
                ('baseline', baseline._project, baseline_db, deepcopy(state)),
                ('candidate', audit.old_project, database, state),
            ):
                token = PHASE.set(phase)
                try:
                    result = await function(db_arg, owner, state_arg, as_of=as_of)
                except Exception as error:
                    outcomes.append(('error', signature(error)))
                    failures.append(error)
                else:
                    outcomes.append(('value', result))
                    failures.append(None)
                finally:
                    PHASE.reset(token)
            assert outcomes[0] == outcomes[1], (audit.current_test, outcomes)
            assert canonical(outcomes[0]) == canonical(outcomes[1]), audit.current_test
            assert state == before_state, 'candidate mutated financial input'
            if before_data is not None:
                assert database.data == before_data == baseline_db.data, 'source input mutation'
            financial = None
            if outcomes[0][0] == 'value':
                financial_outcomes = []
                for result in (outcomes[0][1], outcomes[1][1]):
                    try:
                        report = build_financial_position(deepcopy(before_state), cost_exposure=result,
                                                          generated_at=as_of or state.get('engine', {}).get('as_of'))
                    except Exception as error:
                        financial_outcomes.append(('error', signature(error)))
                    else:
                        financial_outcomes.append(('value', report))
                assert financial_outcomes[0] == financial_outcomes[1]
                assert canonical(financial_outcomes[0]) == canonical(financial_outcomes[1])
                financial = {'kind': financial_outcomes[0][0],
                             'sha256': digest(financial_outcomes[0])}
            audit.comparisons.append({
                'test': audit.current_test, 'fixture': fixture_kind,
                'outcome': outcomes[0][0], 'whole_outcome_sha256': digest(outcomes[0]),
                'whole_output_equal': True, 'financial_report': financial,
                'same_exception_semantics': outcomes[0][0] == 'error',
                'source_data_unchanged': before_data is not None,
                'financial_input_unchanged': True,
            })
            if failures[1] is not None:
                raise failures[1]
            return outcomes[1][1]

        candidate._project = compared_project

    def pytest_runtest_setup(self, item):
        self.current_test = item.nodeid

    def pytest_runtest_logreport(self, report):
        if report.when == 'call' or (report.when in {'setup', 'teardown'} and report.outcome != 'passed'):
            self.tests.append({'nodeid': report.nodeid, 'phase': report.when, 'outcome': report.outcome})

    def pytest_deselected(self, items):
        self.omitted.extend(item.nodeid for item in items)

    def pytest_sessionfinish(self, session, exitstatus):
        candidate_reads = [row for row in self.queries if row['phase'] == 'candidate']
        baseline_reads = [row for row in self.queries if row['phase'] == 'baseline']
        motor_candidate = [row for row in self.motor_queries if row['phase'] == 'candidate']
        motor_baseline = [row for row in self.motor_queries if row['phase'] == 'baseline']
        summary = {
            'base': BASE, 'runtime_file': str(ROOT / RUNTIME),
            'runtime_baseline_sha256': self.baseline_sha256,
            'runtime_candidate_sha256': self.candidate_sha256,
            'candidate_source_unchanged_during_audit': self.candidate_sha256 == hashlib.sha256((ROOT / RUNTIME).read_bytes()).hexdigest(),
            'fields_count': len(self.fields), 'fields_unique_count': len(set(self.fields)),
            'exitstatus': int(exitstatus),
            'pytest_passed': sum(item['outcome'] == 'passed' for item in self.tests),
            'pytest_failed': sum(item['outcome'] == 'failed' for item in self.tests),
            'pytest_skipped': sum(item['outcome'] == 'skipped' for item in self.tests),
            'deselected': self.omitted, 'uncompared_db_types': self.incomparable,
            'full_outcome_comparisons': len(self.comparisons),
            'full_financial_report_comparisons': sum(item['financial_report'] is not None for item in self.comparisons),
            'whole_outputs_equal': all(item['whole_output_equal'] for item in self.comparisons),
            'candidate_projection_reads': len(candidate_reads),
            'baseline_full_reads': len(baseline_reads),
            'candidate_reads_all_53_fields': bool(candidate_reads) and all(set(row['projection_fields']) == set(self.fields) for row in candidate_reads),
            'baseline_reads_all_unprojected': bool(baseline_reads) and all(not row['projection_fields'] for row in baseline_reads),
            'actual_motor_order_queries': self.motor_queries,
            'actual_motor_candidate_reads_all_53_fields': bool(motor_candidate) and all(
                row['projection'] == {'_id': 0, **dict.fromkeys(self.fields, 1)} for row in motor_candidate),
            'actual_motor_baseline_reads_all_unprojected': bool(motor_baseline) and all(
                row['projection'] is None for row in motor_baseline),
            'comparisons': self.comparisons, 'order_reads': self.queries, 'tests': self.tests,
            'limitations': ['Synthetic data only; no production latency claim.',
                            'Omitted-field BSON decoding failures are not asserted equivalent.',
                            'Projection honored only for unified_orders; other fixture behavior unchanged.'],
        }
        target = OUT / ('cost-projection-independent-' + self.output_label + '.json')
        target.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
        compact = {key: value for key, value in summary.items() if key not in {'comparisons', 'order_reads', 'tests', 'deselected'}}
        print('\nIndependent projection audit: ' + json.dumps(compact, ensure_ascii=False))


if __name__ == '__main__':
    sys.path[:0] = [str(ROOT / 'backend'), str(ROOT / 'backend/tests')]
    raise SystemExit(pytest.main(sys.argv[1:], plugins=[Audit()]))
