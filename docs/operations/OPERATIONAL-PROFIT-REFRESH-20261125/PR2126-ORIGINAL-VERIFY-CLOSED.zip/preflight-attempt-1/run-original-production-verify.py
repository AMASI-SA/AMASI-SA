from pathlib import Path
import datetime,json,os,subprocess,sys,time,traceback
e=Path('/tmp/mezan-pr2126-app-dy90mxg3/evidence')
state={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'preflight','cwd':'/app','command':[sys.executable,'-B','scripts/production_release_guard.py','verify','--url','https://mezansalla.com']}
def save():
    p=e/'production-verify-state.json'
    tmp=e/'production-verify-state.own-tmp.json'
    tmp.write_text(json.dumps(state,indent=2)+chr(10))
    tmp.replace(p)
def guard_status(name):
    r=subprocess.run([sys.executable,'-B','scripts/production_release_guard.py','status'],cwd='/app',capture_output=True,text=True)
    (e/(name+'.stdout.json')).write_text(r.stdout)
    (e/(name+'.stderr.log')).write_text(r.stderr)
    assert r.returncode==0, 'original status failed'
    return json.loads(r.stdout)
try:
    save()
    prepared=json.loads((e/'prepare.stdout.json').read_text())
    before=guard_status('verify-before-status')
    assert before.get('active') is True, 'no active lease'
    assert {k:v for k,v in before.items() if k!='active'}==prepared, 'lease changed; stop without altering it'
    assert before.get('actor')=='chatgpt-operational-profit-refresh-20261125-pr2126-39c6dec7c37f', 'actor mismatch'
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/app',text=True).strip()
    tracked=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd='/app',text=True)
    assert head=='f3d8ee39e60ed087f0a4d6debf844d128e92a758', 'deployment head changed'
    assert not tracked.strip(), 'tracked source changed'
    state.update(phase='verifying',deployment_head=head,tracked_clean=True,full_lease_match=True,actor=before['actor'],prepared_at=before['prepared_at'])
    save()
    tick=time.monotonic()
    with (e/'production-verify.stdout.json').open('w') as out,(e/'production-verify.stderr.log').open('w') as err:
        r=subprocess.run(state['command'],cwd='/app',stdout=out,stderr=err)
    state.update(verify_exit_code=r.returncode,verify_seconds=round(time.monotonic()-tick,3),verify_finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    after=guard_status('verify-after-status')
    state['after_status']=after
    state['lease_closed']=after.get('active') is False
    state['verified_success']=r.returncode==0 and state['lease_closed']
    state['phase']='passed' if state['verified_success'] else 'failed'
except Exception as exc:
    state.update(phase='failed',verified_success=False,error=str(exc),exception_type=type(exc).__name__)
    (e/'production-verify-wrapper-exception.log').write_text(traceback.format_exc())
finally:
    state['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print(json.dumps(state,indent=2))
