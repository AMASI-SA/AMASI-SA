from pathlib import Path
import datetime,hashlib,json,zipfile
e=Path('/tmp/mezan-pr2126-app-dy90mxg3/evidence')
s=json.loads((e/'production-verify-state.json').read_text())
if s['phase']=='verifying':
    print('PR2126_PACKAGE_WAIT '+json.dumps({'phase':s['phase'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
    raise SystemExit(0)
assert s['phase']=='passed' and s.get('verify_exit_code')==0 and s.get('verified_success') is True and s.get('lease_closed') is True, 'verification did not pass; preserve and inspect'
v=json.loads((e/'production-verify.stdout.json').read_text())
assert v['verified'] is True and v['checks']==3
assert v['source_git_sha']=='6d4aa546259e9cad1cc379d4a464e245af6cfa91'
assert v['deployment_git_sha']=='f3d8ee39e60ed087f0a4d6debf844d128e92a758'
assert v['release_id']=='rg5-ddf3455ed71fa8a5dd19073323ec8bebe166c868ad4d14215476fd492439a70a'
prepared=json.loads((e/'prepare.stdout.json').read_text())
before=json.loads((e/'verify-before-status.stdout.json').read_text())
after=json.loads((e/'verify-after-status.stdout.json').read_text())
assert before['active'] is True and {k:a for k,a in before.items() if k!='active'}==prepared
assert before['actor']=='chatgpt-operational-profit-refresh-20261125-pr2126-39c6dec7c37f'
assert after['active'] is False and s['after_status']==after
summary={'result':'PASS','original_command':s['command'],'cwd':s['cwd'],'wrapper_started_at':s['started_at'],'verify_finished_at':s['verify_finished_at'],'closed_status_observed_at':s['finished_at'],'elapsed_seconds':s['verify_seconds'],'returncode':s['verify_exit_code'],'source_git_sha':v['source_git_sha'],'deployment_git_sha':v['deployment_git_sha'],'release_id':v['release_id'],'verified':v['verified'],'checks':v['checks'],'protocol_version':v['protocol_version'],'boot_started_at':v['boot_started_at'],'boot_started_at_observations':v['boot_started_at_observations'],'frontend_artifact_tree_sha256':v['frontend_artifact_tree_sha256'],'frontend_checked_requests_count':len(v['frontend_checked_requests']),'actor':before['actor'],'prepared_at':before['prepared_at'],'full_prepared_lease_matches_before':True,'original_status_after':after,'provider_revision':'97dc193','publish_changes_clicks':1,'limits':['The original verifier emits its aggregate result, first frontend request list and distinct boot times; it does not preserve each raw health response.','Publication identity verification does not establish financial source completeness or performance improvement.','First wrapper preflight failed before invoking original verify; its complete artifacts are retained separately.']}
(e/'production-verify-closure-summary.json').write_text(json.dumps(summary,indent=2)+chr(10))
names=['prepare.stdout.json','prepare.stderr.log','prepared-status.json','prepare-receipt.json','prepublish-initial.stdout.json','prepublish-initial.stderr.log','prepublish-initial-receipt.json','prepublish-final.stdout.json','prepublish-final.stderr.log','prepublish-final-receipt.json','publication-submission.json','publication-completed-ui.json','preflight-recovery.json','verification-progress-observation.json','run-original-production-verify.py','production-verify-process.json','production-verify-state.json','production-verify-wrapper.log','production-verify.stdout.json','production-verify.stderr.log','verify-before-status.stdout.json','verify-before-status.stderr.log','verify-after-status.stdout.json','verify-after-status.stderr.log','production-verify-closure-summary.json','package-verify-evidence.py']
names+=sorted(str(p.relative_to(e)) for p in (e/'preflight-attempt-1').iterdir() if p.is_file())
assert len(names)==len(set(names))
manifest={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'Original prepare/prepublish/verify/status outputs and task-owned orchestration, plus explicit UI observations','source_git_sha':v['source_git_sha'],'deployment_git_sha':v['deployment_git_sha'],'release_id':v['release_id'],'files':[]}
archive=e/'PR2126-ORIGINAL-VERIFY-CLOSED.zip'
assert not archive.exists(), 'archive already exists; inspect rather than overwrite'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in names:
        raw=(e/name).read_bytes()
        manifest['files'].append({'name':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
        z.writestr(name,raw)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+chr(10))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(names)+1,'summary':summary}
(e/'production-verify-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+chr(10))
print('PR2126_ARCHIVE_READY '+json.dumps(receipt))
