from pathlib import Path
import subprocess,json,os,time,traceback,shutil
from datetime import datetime,timezone
base=Path('/tmp/mezan-pr2126-app-dy90mxg3');source=Path('/app');ev=base/'evidence'
J='f3d8ee39e60ed087f0a4d6debf844d128e92a758';D='f3d8ee39e60ed087f0a4d6debf844d128e92a758';A='6d4aa546259e9cad1cc379d4a464e245af6cfa91'
def now(): return datetime.now(timezone.utc).isoformat()
def read(args,cwd='/app'):
 p=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=30)
 if p.returncode: raise RuntimeError('precondition_command_failed_'+str(p.returncode)+'_'+args[0])
 return p.stdout.strip()
def snapshot():
 return {'at':now(),'main_head':read(['git','rev-parse','HEAD']),'main_tracked_changes':read(['git','status','--porcelain','--untracked-files=no']),'isolated_head':read(['git','rev-parse','HEAD'],source),'isolated_changes':read(['git','status','--porcelain','--untracked-files=no'],source),'guard':json.loads(read(['python','-B','scripts/production_release_guard.py','status'])),'app_free_bytes':shutil.disk_usage('/app').free,'tmp_free_bytes':shutil.disk_usage('/tmp').free}
state={'phase':'app_D','started_at':now(),'runner_pid':os.getpid(),'source':str(source),'steps':[],'finished':False}
def save():
 p=ev/'rehearsal-state.tmp';p.write_text(json.dumps(state,indent=2)+chr(10));p.replace(ev/'rehearsal-state.json')
try:
 state['before']=snapshot();before=state['before']
 if before['main_head']!=J or before['main_tracked_changes'] or before['isolated_head']!=D or before['isolated_changes'] or before['guard'].get('active') is not False: raise RuntimeError('preconditions_changed')
 env=dict(os.environ)
 for key in ('GITHUB_ACTIONS','GITHUB_SHA','GITHUB_WORKSPACE'): env.pop(key,None)
 env.update(XDG_CACHE_HOME=str(base/'cache'),TMPDIR=str(base/'tmp'),TMP=str(base/'tmp'),TEMP=str(base/'tmp'),PYTHONDONTWRITEBYTECODE='1',REACT_APP_BACKEND_URL='https://mezansalla.com',CI='false')
 commands=[(source/'frontend',['yarn','build']),(source,['python','-B','scripts/verify_frontend_build.py','--expected-git-sha',A,'--reviewed-intent-v5']),(source,['python','-B','scripts/emergent_deployment_adapter.py','verify-packages'])]
 save()
 for index,(cwd,argv) in enumerate(commands,1):
  step={'index':index,'cwd':str(cwd),'argv':argv,'started_at':now(),'log':str(ev/('step-'+str(index)+'.log'))};state['steps'].append(step);save();start=time.monotonic()
  with open(step['log'],'w') as log: result=subprocess.run(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  step.update(returncode=result.returncode,elapsed_seconds=round(time.monotonic()-start,3),finished_at=now());save()
  if result.returncode: raise RuntimeError('original_step_'+str(index)+'_failed_'+str(result.returncode))
 state['after']=snapshot();after=state['after']
 if after['main_head']!=J or after['main_tracked_changes'] or after['isolated_head']!=D or after['isolated_changes'] or after['guard'].get('active') is not False: raise RuntimeError('postconditions_changed')
 state['result']='PASS'
except Exception as error:
 state['result']='FAIL';state['error_type']=type(error).__name__;state['reason']=str(error)[:500]
finally:
 state['finished']=True;state['finished_at']=now();save();print(json.dumps({'rehearsal_result':state['result'],'finished_at':state['finished_at']}),flush=True)
